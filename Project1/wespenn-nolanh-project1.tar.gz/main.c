#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <signal.h>
#include <string.h>
#include <sys/wait.h>
#include <fcntl.h>
#include "parser.h"

#define MAX_LINE_LENGTH 4096

/**
 * ==========================================
 * Function: waitForChildren
 * ==========================================
 * 
 * Waits for a child command
 * 
 * [params]:
 * int * pidArr: the array of PIDs of the commands
 * int * childrenFinished: a sudo boolean value which 
 * represents if all children up to this child have exited
 * or not
 * 
 * [returns]: the status of the child
 */
int waitForChildren(int * pidArr, int numChildren, int * childrenFinished) {
    //need to make sure not to touch pidArr itself so that we 
    *childrenFinished = 1;
    for(int i = 0; i < numChildren; i++){
        int status;
        if(pidArr[i] == 0){
            *childrenFinished = 0;
        } else{
            if(waitpid(pidArr[i], &status, 0) == -1){
                return -1;
            }
            *childrenFinished &= WIFEXITED(status) || WIFSIGNALED(status);
        }
    }
    return *childrenFinished;
}



/**
 * ==========================================
 * Function: strCpy
 * ==========================================
 * 
 * Copies a string
 * 
 * [params]:
 * char *dest: the string that is being copied to
 * char *src: the string that is being copies from
 * 
 * [returns]: the copied string
 */
char *strCpy(char *dest, char *src) {
    char *cmpCopy = dest;
    while(*src != '\0'){
        *dest = *src;
        src++;
        dest++;
    }
    *dest = '\0';
    return cmpCopy;
}



/**
 * ==========================================
 * Function: signalFunction
 * ==========================================
 * 
 * Handles ^C
 * 
 * [params]:
 * int signo: the signal number
 * 
 * [returns]: void
 */
void signalFunction(int signo) { //TODO: Fix Control-C Logic (Or don't)
    write(STDERR_FILENO, "\n", 2);
}

void closePipeWrites(int ** fdArr, int numPipes){
    for (int i = 0; i < numPipes; i++){
        close(fdArr[i][1]);
    }
}

int executeCommand(int pipeIndex, struct parsed_command * pCmd, int * pidArr, int ** fdArr){
    char ** newargv = pCmd->commands[pipeIndex];

    /*
    ================================
    5) Handle just pressing enter
    ================================
    */
    if (newargv == NULL) {
        return -1;
    }
    /*
    ================================
    6) Fork and execute
    ================================
    */
    int pid = fork();
    pidArr[pipeIndex] = pid;
    if (pid == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    } else if (pid == 0) { //Child Process
        int new_stdout, new_stdin;
        
        /**
         * First Pipe 
        */
        if(pipeIndex == 0){
            if(pCmd->stdin_file){
                new_stdin = open(pCmd->stdin_file, O_RDONLY, 0644);
                dup2(new_stdin, STDIN_FILENO);
                close(new_stdin);
            }
            if (pCmd->num_commands > 1){
                dup2(fdArr[pipeIndex][1], STDOUT_FILENO); //Write to Standard Out into Pipe 0
            }
        }

        /**
         * Intermediate Pipe 
        */
        if(pipeIndex > 0 && pipeIndex < pCmd->num_commands - 1) {
            dup2(fdArr[pipeIndex - 1][0], STDIN_FILENO); //read from standard-in into last pipe
            dup2(fdArr[pipeIndex][1], STDOUT_FILENO); // write to standard-out into pipe
        }

        /**
         * Last Pipe 
        */
        if(pipeIndex == pCmd->num_commands - 1){ //Another If Statement In case of 1 pipe
            if(pCmd->stdout_file){
                int flags = O_WRONLY | O_CREAT;
                if(pCmd->is_file_append) {
                    flags |= O_APPEND;
                } else {
                    flags |= O_TRUNC;
                }

                new_stdout = open(pCmd->stdout_file, flags, 0644);
                dup2(new_stdout, STDOUT_FILENO);
                close(new_stdout);
            }
            if(pCmd -> num_commands > 1){
                dup2(fdArr[pipeIndex - 1][0], STDIN_FILENO);
            }
        }

        //Close all Sibling Write Sides
        closePipeWrites(fdArr, pCmd->num_commands - 1);
        if (execvp(newargv[0], newargv) == -1) {
            free(pCmd);
            perror("execve");
            exit(EXIT_FAILURE);
        }
    } else if (pidArr[pipeIndex] > 0) {} //Parent Process (Logic moved to runShell)

    return 0;
}


/**
 * ==========================================
 * Function: parseInput
 * ==========================================
 * 
 * Runs the penn-shell shell
 * 
 * [params]:
 * 
 * [returns]: an integer
 */
int runShell() {
    while(1){
        /*
        ================================
        1) Handle ^C
        ================================
        */
        if(signal(SIGINT, signalFunction) == SIG_ERR){
            printf("ERROR: SIG_ERR.");
            exit(EXIT_FAILURE);
        }
        int numBytes;

        char cmd[MAX_LINE_LENGTH];
        if(isatty(STDIN_FILENO)){ //CHECK IF PROMPT IS REDIRECTED
            /*
            ================================
            2) Print prompt and read in 
            from command line
            ================================
            */
            write(STDERR_FILENO, PROMPT, strlen(PROMPT));
            numBytes = read(STDIN_FILENO, cmd, MAX_LINE_LENGTH);
        } else{
            size_t bufsize = MAX_LINE_LENGTH;
            char *cmdPtr = cmd;
            numBytes = getline(&cmdPtr,&bufsize,stdin);
            if (numBytes == -1) {
                break;
            }
        }

        cmd[numBytes] = 0;

        /*
        ================================
        3) Handle ^D
        ================================
        */
        if(numBytes == 0) {
            if(isatty(STDIN_FILENO)){
                write(STDOUT_FILENO, "\n", 2);
            }
            exit(EXIT_SUCCESS);
        }

        struct parsed_command *pCmd;
        int parseCode = parse_command((char *) cmd, &pCmd);
        if(parseCode != 0){
            printf("Parse Error [%d]: Invalid Command\n", parseCode);
            continue;
        }
        
        //Handle Control-D With No Arguments
        if(cmd[strlen(cmd) - 1] != '\n'){
            write(STDOUT_FILENO, "\n", 2);
        }

        int * pidArr = (int *) malloc(pCmd->num_commands * sizeof(int)); //TODO: Note that we may need to null terminate
        int ** fdArr = (int **) malloc((pCmd->num_commands) * sizeof(int *)); //NOTE: Write Error: Changed from num_commands - 1 to num_commands
        for(int i = 0; i < pCmd->num_commands; i++){
            fdArr[i] = (int *) malloc(2 * sizeof(int));
            pipe(fdArr[i]);
        }
        for(int i = 0; i < pCmd->num_commands; i++){
            if(executeCommand(i, pCmd, pidArr, fdArr) == -1){
                continue;
            }
        }
        /**
         * Parent Process: Moved from execute Command
         */
        //Close all parent pipes
        closePipeWrites(fdArr, pCmd->num_commands - 1);

        //Parent logic
        int childrenFinished;
        do {
            if(waitForChildren(pidArr, pCmd->num_commands, &childrenFinished) == -1){
                free(pCmd);
                perror("pidwait");
                exit(EXIT_FAILURE);
            }
        } while(!childrenFinished);

        for (int i = 0; i < pCmd->num_commands; i++){
            free(fdArr[i]);
        }
        free(fdArr);
        free(pidArr);
        free(pCmd);
    }
    return 0;
}



/**
 * ==========================================
 * Function: main
 * ==========================================
 * 
 * The entry point for penn-shell
 * 
 * [params]:
 * int argc: number of arguments
 * cahr **argv: the arguments
 * 
 * [returns]: an integer
 */
int main(int argc, char **argv) {
    if (argc == 1) {
        runShell();
    } else {
        char errorPrompt[] = "ERROR. Usage: penn-shell\n";
        int errorPromptLength = strlen(errorPrompt);
        write(STDERR_FILENO, errorPrompt, errorPromptLength);
        exit(EXIT_FAILURE);
    }
}