#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include "fsHandler.h"
#include "directoryEntryManager.h"

/**
 * ===============
 * GLOBALS
 * ===============
 */

//TODO: We may want to make these variables static so that they are accessible across each other?

//useful constants
const int BLOCK_SIZE[] = {256, 512, 1024, 2048, 4096};
const uint16_t defaultVal = 0xFFFF; // 65535; //TODO: IS this supposed to be signed? --> i.e. negative 1?
const int DIR_ENTRY_SIZE = 64;

//base block size and block number inputs to mounted Fs
int currBlockSizeConfig = 0;
int currBlocksInFat = 0;

//useful abstracted values for mounted Fs
int currBlockSizeBytes = 0;
int curTotNumFatEntries = 0;
int currNumDirEntries = 0;

//sizes of the FAT and DATA regions of the Binary Fs file
int currFatRegionSize = 0;
int currDataRegionSize = 0;

//file descriptor of the curent mounted file system
char * currFsName = NULL;
int fsFd = -1;

// Root Directory
struct directory_entry * rootDirectory = NULL;

// FAT
uint16_t * fat = NULL;

/**
 * Helper Functions
*/

int safeFdCheck() {
  if(currFsName == NULL){
    return -1;
  }
  // if(fcntl(fsFd, F_GETFD) == -1) {} <== DID NOT WORK BUT WHY?????
  if (fsFd != -1){
    close(fsFd);
  }
  fsFd = open(currFsName, O_RDWR);
  if (fsFd == -1) {
    printf("ERROR ON SAFE READ/WRITE.\n");
    exit(EXIT_FAILURE);
  }
  return 1;
}

int safeRead(off_t offset, void * buff, size_t size){
  if (safeFdCheck() == -1){
    return -1;
  }
  if (offset != -1){
    lseek(fsFd, offset, SEEK_SET);
  }
  read(fsFd, buff, size);
  return 1;
}

int safeWrite(off_t offset, const void * buff, size_t size) {
  if (safeFdCheck() == -1){
    printf("Write Error\n");
    exit(EXIT_FAILURE);
  }
  if (offset != -1){
    lseek(fsFd, offset, SEEK_SET);
  }
  return write(fsFd, buff, size);
}


int min(int x, int y){
  if (x > y){
    return y;
  }
  return x;
}

int max(int x, int y){
  if (x > y){
    return x;
  }
  return y;
}

int findFirstOpenDataBlockNumber(){
  int fatIndex = 1;
  while (fatIndex < curTotNumFatEntries) {
    // printf("%d\n", fatIndex);
    if (fat[fatIndex] == 0) {
      return fatIndex;
    }
    fatIndex++;
  }
  return -1; //no open blocks
}

int findMetaDataLocation(char * targetFile){
  int dataBlockNum = 1;
  while (dataBlockNum != defaultVal){
    int directoryEntry = 0;
    int dataBlockLoc = currFatRegionSize + currBlockSizeBytes * (dataBlockNum - 1);
    while (directoryEntry < currNumDirEntries){
      char fileName[32];
      safeRead(dataBlockLoc + 64 * directoryEntry, fileName, sizeof(fileName));
      if(strcmp(fileName, targetFile) == 0){
        lseek(fsFd, 0, SEEK_SET);
        return dataBlockLoc + 64 * directoryEntry;
      }
      directoryEntry++;
    }
    dataBlockNum = fat[dataBlockNum];
  }
  lseek(fsFd, 0, SEEK_SET);
  return -1;
}

int findOpenMetaDataLocation(){
  int dataBlockNum = 1;
  while (dataBlockNum != defaultVal){
    int directoryEntry = 0;
    int dataBlockLoc = currFatRegionSize + currBlockSizeBytes * (dataBlockNum - 1);
    while (directoryEntry < currNumDirEntries){
      char fileName[32];
      safeRead(dataBlockLoc + 64 * directoryEntry, fileName, sizeof(fileName));
      if(fileName[0] == 0 || fileName[0] == 1 || fileName[0] == 2){
        // lseek(fd, 0, SEEK_SET);
        return dataBlockLoc + 64 * directoryEntry;
      }
      directoryEntry++;
    }
    dataBlockNum = fat[dataBlockNum];
  }
  // lseek(fd, 0, SEEK_SET);
  return -1;
}

int findEODDataRegion(){
  int blockNum = 1;
  while(fat[blockNum] != defaultVal){
    blockNum = fat[blockNum];
  }
  return blockNum;
}

int getAmountOfAvailableSpace() {
  int index = 0;
  int numEmptyBlocks = 0;

  while (index < curTotNumFatEntries) {
    // printf("Index: %d\n", index);
    if (fat[index] == 0x0000) {
      numEmptyBlocks++;
    }
    index++;
  }

  // printf("NUM EMPTY BYTES: %d, %d, %d\n", numEmptyBlocks, currBlockSizeBytes,  numEmptyBlocks * currBlockSizeBytes);

  return numEmptyBlocks * currBlockSizeBytes;
}

void clearDataBlock(int dataBlockLocation){
  uint64_t fillZero = 0; //8 B
  for(int i = 0; i < currBlockSizeBytes / 8; i++){
    safeWrite(dataBlockLocation + i * 8, &fillZero, sizeof(fillZero));
  }
}

void clearMetadataBlock(int mdBlockLocation){
  uint64_t fillZero = 0; //8 B
  for(int i = 0; i < 8; i++){ // 64 B MD Size / 8B = 8 iterations
    safeWrite(mdBlockLocation + i * 8, &fillZero, sizeof(fillZero));
  }
}

/**
 * ============================
 * SystemCalls Helpers
 * ============================
 */

struct directory_entry * getHead() {
  return rootDirectory;
}

int getLengthOfFile(char * fileName){
  struct directory_entry * fileEntry = findDirEntry(fileName, rootDirectory);
  if (fileEntry == NULL){
    printf("ERROR: File Does Not Exist in Root Directory.\n");
    return -1;
  }
  int lengthOfFile = 0;
  int curBlockNum = fileEntry->firstBlock;
  char * fileBuff = (char *) malloc(currBlockSizeBytes);
  while(curBlockNum != defaultVal){
    int dataBlockLoc = currFatRegionSize + (curBlockNum - 1) * currBlockSizeBytes;
    safeRead(dataBlockLoc, fileBuff, currBlockSizeBytes);
    lengthOfFile += strlen(fileBuff);
    curBlockNum = fat[curBlockNum];
  }
  free(fileBuff);
  return lengthOfFile;
}

// On return, returns the number of bytes read, 0 if EOF is reached, or a negative number on error.
int getAllFileData(char * buf, char * fileName, int offset, int bytes) { //Note: Need to free return string when calling this function
  struct directory_entry * fileEntry = findDirEntry(fileName, rootDirectory);
  if (fileEntry == NULL){
    return -1;
  }
  if (fileEntry->size == 0){
    return 0; //EOF
  }
  // if (bytes + offset > fileEntry->size){
  //   return NULL;
  // }

  int dataBlockNum = fileEntry->firstBlock;
  int offsetBlocks = (int) (offset / currBlockSizeBytes);
  int remainingOffset = offset - offsetBlocks * currBlockSizeBytes;
  for(int i = 0; i < offsetBlocks; i ++){
    if (dataBlockNum == defaultVal){
      return -1;
    }
    dataBlockNum = fat[dataBlockNum];
  }

  int dataLoc = -1;
  // char * outputString = (char *) calloc(bytes, sizeof(char));
  memset(buf, 0, bytes);
  int remainingBytes = bytes;
  while(remainingBytes > 0 && dataBlockNum != defaultVal){
    char * fileBuff = (char *) calloc(currBlockSizeBytes, sizeof(char));
    dataLoc = currFatRegionSize + (dataBlockNum - 1) * currBlockSizeBytes + remainingOffset;
    safeRead(dataLoc, fileBuff, min(currBlockSizeBytes - remainingOffset, remainingBytes));
    
    remainingBytes -= strlen(fileBuff);
    strcat(buf, fileBuff);

    remainingOffset = 0;
    dataBlockNum = fat[dataBlockNum];
    free(fileBuff);
  }
  if (remainingBytes > 0){
    return 0; //EOF
  }
  return strlen(buf);
}

int writeToFileData(char * str, char * fileName, int offset, int bytes){
  struct directory_entry * fileEntry = findDirEntry(fileName, rootDirectory);
  if (fileEntry == NULL){
    return -1;
  }
  if (bytes > getAmountOfAvailableSpace()) {
    return -1;
  }
  
  int offsetBlocks = (int) (offset / currBlockSizeBytes);
  int remainingOffset = offset - offsetBlocks * currBlockSizeBytes;
  if (fileEntry->size == 0 && offsetBlocks == 0){
    int newDataBlockNum = findFirstOpenDataBlockNumber();
    fat[newDataBlockNum] = defaultVal;
    fileEntry->firstBlock = newDataBlockNum;
    clearDataBlock((newDataBlockNum - 1) * currBlockSizeBytes + currFatRegionSize);
    int medaDataLocation = findMetaDataLocation(fileEntry->name);
    uint16_t firstBlockWrite = newDataBlockNum;
    safeWrite(medaDataLocation + 32 + 4, &firstBlockWrite, sizeof(firstBlockWrite));
  } else if (fileEntry->size == 0 && offsetBlocks > 0){
    return -1;
  }
  int dataBlockNum = fileEntry->firstBlock;
  for(int i = 0; i < offsetBlocks; i ++){
    if (dataBlockNum == defaultVal){
      return -1;
    }
    dataBlockNum = fat[dataBlockNum];
  }

  int dataLoc = -1;
  int remainingBytes = bytes;
  char * strPtr = str;
  while (remainingBytes > 0) {
    dataLoc = currFatRegionSize + (dataBlockNum - 1) * currBlockSizeBytes + remainingOffset;
    int writeAmount = min(remainingBytes, currBlockSizeBytes - remainingOffset);
    safeWrite(dataLoc, strPtr, writeAmount);

    strPtr+= writeAmount;
    remainingBytes -= writeAmount;
    remainingOffset = 0;

    //Create New Data Block
    if (remainingBytes > 0 && fat[dataBlockNum] == defaultVal){
      int newDataBlockNum = findFirstOpenDataBlockNumber();
      fat[dataBlockNum] = newDataBlockNum;
      fat[newDataBlockNum] = defaultVal;
      
      clearDataBlock((newDataBlockNum - 1) * currBlockSizeBytes + currFatRegionSize);
    }
    dataBlockNum = fat[dataBlockNum];
  }

  int medaDataLocation = findMetaDataLocation(fileEntry->name);
  uint32_t newSizeWrite = max(offset + bytes, fileEntry->size);
  safeWrite(medaDataLocation + 32, &newSizeWrite, sizeof(newSizeWrite));
  fileEntry->size = newSizeWrite;
  
  return bytes;
}

/**
 * ===============
 * mkfs
 * ===============
 */
void mkfs_command(char * fsName, int blocksInFAT, int blockSizeConfig) {

    /*
    1.1) TODO: Parse and check for errors
    */

    if(access(fsName, F_OK ) == 0){ //TODO: Fixes RM Problem--> See rmCommand in fsHandler.c
      printf("Filesystem  Exists.\n");
      return;
    } else {
      printf("Creating new filesystem...\n");
    }

    if (blockSizeConfig > 4 || blockSizeConfig < 0){
        printf("I/O User Error: BlockSizeConfig");
        return;
    }

    int blockSizeBytes = BLOCK_SIZE[blockSizeConfig];

    if (blocksInFAT > 32 || blocksInFAT < 1) {
      printf("I/O User Error: Invalid number of blocrmks");
      return;
    }
    
    /*
    1.2) Open a binary file named fsName
    */
    FILE *fs = fopen(fsName, "wb"); //TODO: Change to w

    int fd = fileno(fs);

    // int fd = open(fsName, O_CREAT | O_RDWR | O_TRUNC);

    int sizeOfFatRegion = blockSizeBytes * blocksInFAT;
    int numFATEntries = sizeOfFatRegion / 2;
    int sizeOfDataRegion = blockSizeBytes * (numFATEntries - 1);
    int numBytesTotal = sizeOfFatRegion + sizeOfDataRegion;

    if (ftruncate(fd, numBytesTotal) != 0) {
      printf("ftruncate() error");
      return;
    }

    /*
    2) Store the relevant information in the binary file based
    off of the paramaters to this function and the default vals
    for the root directory
    */

    write(fd, &blockSizeConfig, sizeof(blockSizeConfig));

    lseek(fd, 1, SEEK_SET); //sets the offset for storing the second byte of data
    write(fd, &blocksInFAT, sizeof(blocksInFAT));

    lseek(fd, 2, SEEK_SET); //sets the offset for storing the root directory default "FFFF"
    write(fd, &defaultVal, sizeof(blocksInFAT));

    fclose(fs);
    // close(fd);
    // printf("1) Successfully Created FS %s!\n\n", fsName);
}



/**
 * ===============
 * mount
 * ===============
 */
void setGlobalsSizing(u_int16_t blockSizeConfig, u_int16_t blocksInFat){
  // printf("4) Setting Global Sizing\n\n");
  currBlockSizeConfig= blockSizeConfig;
  currBlocksInFat = blocksInFat;

  currBlockSizeBytes = BLOCK_SIZE[blockSizeConfig];
  currFatRegionSize = BLOCK_SIZE[blockSizeConfig] * blocksInFat;

  curTotNumFatEntries = currFatRegionSize / 2;
  currDataRegionSize = currBlockSizeBytes * (curTotNumFatEntries - 1);

  currNumDirEntries = currBlockSizeBytes / 64;
}

void populateDataStructures(int fs_fd){
  // printf("6) Populating data structures...\n\n");

  // int fs_fd = open(currFsName, O_RDWR);

  u_int16_t currRootDirPointer = 1;

  int errorCounter = 0; //TODO: This will always skip the while loop --> 0 does not satisfy errorCounter > 17000

  while (currRootDirPointer != defaultVal || errorCounter > 17000) {

    // printf("\nBLOCK NUMBER: %X\n", currRootDirPointer);
    
    int dirBlockOffset = (currRootDirPointer == 1) ? currFatRegionSize : currFatRegionSize + (currRootDirPointer - 1) * currBlockSizeBytes;
    int dirEntryCounter = 0;

    while (dirEntryCounter < currNumDirEntries) {

      //char * fileName = malloc( 32 * sizeof(char) );
      char fileName[32];
      
      uint32_t size = 0;
      uint16_t firstBlock = 0;
      uint8_t type = RegularFile;
      uint8_t perm = NoFilePermissions;
      time_t curTime = time(NULL);

      lseek(fs_fd, dirBlockOffset + dirEntryCounter * DIR_ENTRY_SIZE, SEEK_SET);

      read(fs_fd, fileName, sizeof(fileName)); //name

      //printf("%s\n", fileName);

      if (fileName[0] != 0 && fileName[0] != 1 && fileName[0] != 2) {

        lseek(fs_fd, dirBlockOffset + dirEntryCounter * DIR_ENTRY_SIZE + 32, SEEK_SET);

        read(fs_fd, &size, sizeof(size)); //size

        lseek(fs_fd, dirBlockOffset + dirEntryCounter * DIR_ENTRY_SIZE + 36, SEEK_SET);
        
        read(fs_fd, &firstBlock, sizeof(firstBlock)); //firstBlock

        lseek(fs_fd, dirBlockOffset + dirEntryCounter * DIR_ENTRY_SIZE + 38, SEEK_SET);
        
        read(fs_fd, &type, sizeof(type)); //type

        lseek(fs_fd, dirBlockOffset + dirEntryCounter * DIR_ENTRY_SIZE + 39, SEEK_SET);

        read(fs_fd, &perm, sizeof(perm)); //perm

        lseek(fs_fd, dirBlockOffset + dirEntryCounter * DIR_ENTRY_SIZE + 40, SEEK_SET);
    
        read(fs_fd, &curTime, sizeof(curTime)); //mtime

        rootDirectory = insertNewDirEntry(fileName, size, firstBlock, type, perm, curTime, rootDirectory);

      } 

      //free(fileName);

      dirEntryCounter++;
    }

    // printf("%d\n", currRootDirPointer);
    currRootDirPointer = fat[currRootDirPointer];

    errorCounter++;
  }

  if (errorCounter > 17000) {
    printf("[TIMEOUT ERROR] Binary file system corrupt");
    return;
  }

  // close(fs_fd);

  // return head;
}

void mountFsCommand(char * fsName){
  if (currFsName != NULL){
    printf("ERROR: Filesystem %s is Mounted, Cannot Mount Another Filesystem. Run 'unmount' to unmount %s.\n", currFsName, currFsName);
    return;
  }
  // printf("2) Starting mount: %s ...\n\n", fsName);
  currFsName = fsName;
  // fsFd = open(fsName, O_RDWR);
  // printf("3) Opened File: %s, FD = %d ...\n\n", fsName, fs_fd);
  
  u_int16_t blockSizeConfig = 0;
  u_int16_t blocksInFat = 0;

  safeRead(-1, &blockSizeConfig, 1);
  safeRead(1, &blocksInFat, 1);

  setGlobalsSizing(blockSizeConfig, blocksInFat);

  fat = mmap(NULL, currFatRegionSize, PROT_READ | PROT_WRITE, MAP_SHARED, fsFd, 0);
  // printf("5) Mapped data\n\n");

  // printLinkedList(rootDirectory);
  populateDataStructures(fsFd);
  printLinkedList(rootDirectory);
}

/**
 * ===============
 * Unmount
 * ===============
 */
void unmountFsCommand() {
  if (currFsName == NULL){
    printf("ERROR: No filesystem mounted. \n");
    return;
  }
  // printLinkedList(rootDirectory);
  //reset queue
  clearList(&rootDirectory);

  //reset base block size and block number inputs to mounted Fs
  currBlockSizeConfig = 0;
  currBlocksInFat = 0;

  //reset useful abstracted values for mounted Fs
  currBlockSizeBytes = 0;
  curTotNumFatEntries = 0;

  //reset sizes of the FAT and DATA regions of the Binary Fs file
  currFatRegionSize = 0;
  currDataRegionSize = 0;

  //reset file descriptor of the curent mounted file
  currFsName = NULL;
  if (fsFd != -1){
    close(fsFd);
  }
  fsFd = -1;

  fat = NULL;
}

/** 
 * 
 * Touch
 * 
*/
void touchCommand(char ** fileNames){ //Note: files needs to be null terminated
  if (currFsName == NULL){
    printf("ERROR: No filesystem mounted. \n");
    return;
  }
  // printf("CHECK GLOBALS\n");
  // printf("Blocks in FAT: %d, BlockConfig: %d, NumDirEntries: %d\n", currBlocksInFat, currBlockSizeConfig, currNumDirEntries);

  // int fs_fd = open(currFsName, O_RDWR);
  int rootDirectoryLoc = currFatRegionSize;

  char * fileName = *fileNames;
  while (fileName != NULL){
    lseek(fsFd, rootDirectoryLoc, SEEK_SET); //Reset read location to the root directory start
    // printf("Touching File %s into filesystem...\n", fileName);
    if(findDirEntry(fileName, rootDirectory) == NULL){
      // printf("File %s not in filesystem [%d], creating new file...\n", fileName, rootDirectory == NULL);
      time_t curTime = time(NULL);
      // rootDirectory = insertNewDirEntry(fileName, 0, 0, RegularFile, ReadWritePermissions, curTime, rootDirectory);
      // printLinkedList(rootDirectory);
      
      int mdBlockLocation = findOpenMetaDataLocation();
      
      if (mdBlockLocation != -1){
        // lseek(fsFd, mdBlockLocation, SEEK_SET);
        uint64_t clearZero = 0; //8B --> 64B / 8 = 8 iterations
        for (int i = 0; i < 8; i++){
          safeWrite(mdBlockLocation + i * 8, &clearZero, sizeof(clearZero));
        }
        
        // lseek(fsFd, mdBlockLocation, SEEK_SET);
        safeWrite(mdBlockLocation, fileName, strlen(fileName)); //name
        // lseek(fsFd, mdBlockLocation + 32, SEEK_SET);
          
        uint32_t newSize = 0;
        safeWrite(mdBlockLocation + 32, &newSize, sizeof(newSize)); //size
        
        uint16_t newFB = 0;
        safeWrite(mdBlockLocation + 32 + 4, &newFB, sizeof(newFB)); //firstBlock
        
        uint8_t newType = RegularFile;
        safeWrite(mdBlockLocation + 32 + 4 + 2, &newType, sizeof(newType)); //type

        uint8_t newPerm = ReadWritePermissions; //EC Value
        safeWrite(mdBlockLocation + 32 + 4 + 2 + 1, &newPerm, sizeof(newPerm)); //perm

        safeWrite(mdBlockLocation + 32 + 4 + 2 + 1 + 1, &curTime, sizeof(curTime)); //mtime


        rootDirectory = insertNewDirEntry(fileName, 0, 0, RegularFile, ReadWritePermissions, curTime, rootDirectory);
      } else{
        printf("Creating a new directory data block...\n");
        int blockNumIndex = 1;
        int updatedDataRegion = 0;

        //1) identify block number of the end of the directory ( oldEndOfDirectoryBlockNumber ) [HELPER FUNCTION]
        int eodDataRegion = findEODDataRegion();
        // printf("EOD Data Region Block Num: %d\n", eodDataRegion);
        while (blockNumIndex < curTotNumFatEntries && updatedDataRegion == 0){
          // printf("Iteration %d / %d (%f)\n", blockNumIndex + 1, curTotNumFatEntries,  ((float) (blockNumIndex + 1) / (float) curTotNumFatEntries));
          // printf("Curr Fat Entry fat[%d] = %d\n", blockNumIndex, fat[blockNumIndex]);
          if (fat[blockNumIndex] == 0) {

            // 2) set fat[blockNumber] = 0xFFFF
            fat[blockNumIndex] = defaultVal;
            // 3) set fat[eodBlock] = blockNumber
            fat[eodDataRegion] = blockNumIndex;
            // 4) lseek to the new blockNumber in DATA region


            int blockStartNumber = currFatRegionSize + (blockNumIndex - 1) * currBlockSizeBytes;

            // printf("Location of new Dir Block: [%d + %d * %d ] = %d\n", currFatRegionSize, blockNumIndex - 1, currBlockSizeBytes, blockStartNumber);
            clearDataBlock(blockStartNumber);

            safeWrite(blockStartNumber, fileName, strlen(fileName)); //name
              
            uint32_t newSize = 0;
            safeWrite(blockStartNumber + 32, &newSize, sizeof(newSize)); //size
            
            uint16_t newFB = 0;
            safeWrite(blockStartNumber + 32 + 4, &newFB, sizeof(newFB)); //firstBlock
            
            uint8_t newType = RegularFile;
            safeWrite(blockStartNumber + 32 + 4 + 2, &newType, sizeof(newType)); //type

            uint8_t newPerm = ReadWritePermissions; //EC Value
            safeWrite(blockStartNumber + 32 + 4 + 2 + 1, &newPerm, sizeof(newPerm)); //perm

            safeWrite(blockStartNumber + 32 + 4 + 2 + 1 + 1, &curTime, sizeof(curTime)); //mtime


            updatedDataRegion = 1;
          }
          blockNumIndex++;
        }
        if (updatedDataRegion == 0){
          printf("Cannot Touch file %s. File System is full. Please Mount a larger FS.\n", fileName);
        } else {
          rootDirectory = insertNewDirEntry(fileName, 0, 0, RegularFile, ReadWritePermissions, curTime, rootDirectory);
        }
      }
    } else {
      time_t curTime = time(NULL);
      rootDirectory = updateDirEntry(NULL, NULL, NULL, NULL, NULL, &curTime, fileName, rootDirectory);
      // printLinkedList(rootDirectory);
      int mdLocation = findMetaDataLocation(fileName);
      // lseek(fs_fd, mdLocation + 40, SEEK_SET);
      safeWrite(mdLocation + 40, &curTime, sizeof(curTime));
    }
    // printf("Finished touching file %s.\n", fileName);
    fileNames++;
    fileName = *fileNames;
  }
  // close(fs_fd);
}


void mvCommand(char * source, char * dest){
  if (currFsName == NULL){
    printf("ERROR: No filesystem mounted. \n");
    return;
  }
  /**
   * 1.) update linked list
   * 2.) update root directory
  */
  // printf("MV COMMAND\n");
  // int fs_fd = open(currFsName, O_RDWR);
  time_t curTime = time(NULL);

  // 1.) Update linked list
  if (findDirEntry(source, rootDirectory) != NULL){
    if (findDirEntry(dest, rootDirectory) != NULL){
      char * outputFileArr[2] = {dest, NULL};
      rmCommand(outputFileArr, DeletedEntryAndFile);
    }
    rootDirectory = updateDirEntry(&dest, NULL, NULL, NULL, NULL, &curTime, source, rootDirectory);
  } else {
    printf("ERROR: SOURCE file does not exist [in commmand mv SOURCE DEST].\n");
    return;
  }

  // 2.) Update Root Directory (in Data Region)
  int dataBlockNum = 1;
  int updated = 0;
  while(dataBlockNum != defaultVal && updated == 0){
    // printf("DATA BLOCK NUM: %d [%X]\n", dataBlockNum, dataBlockNum);
    int dirBlockLoc = currFatRegionSize + (dataBlockNum - 1) * currBlockSizeBytes;
    lseek(fsFd, dirBlockLoc, SEEK_SET);

    int dirEntryNum = 0;
    while(dirEntryNum < currNumDirEntries && updated == 0){
      // lseek(fs_fd, dirBlockLoc + dirEntryNum * 64, SEEK_SET);
      char fileName[32];
      safeRead(dirBlockLoc + dirEntryNum * 64, fileName, sizeof(fileName));
      // printf("CURRENT FILENAME: %s, SOURCE: %s [%d]\n", fileName, source, strcmp(fileName, source));
      if (strcmp(fileName, source) == 0){
        // printf("[%d] Updating Block NUM: %d, DIR ENTRY NUM: %d\n", dirBlockLoc + dirEntryNum * 64, dataBlockNum, dirEntryNum);
        //clear previous name
        uint64_t fillZero = 0;
        for(int i = 0; i < 4; i++){
          safeWrite(dirBlockLoc + dirEntryNum * 64 + i * 8, &fillZero, sizeof(fillZero));
        }
        //write new file name
        // lseek(fs_fd, dirBlockLoc + dirEntryNum * 64, SEEK_SET);
        // write(fs_fd, dest, strlen(dest));
        safeWrite(dirBlockLoc + dirEntryNum * 64, dest, strlen(dest));
        updated = 1;
      }
      dirEntryNum++;
    }
    dataBlockNum = fat[dataBlockNum];
  }
  // close(fs_fd);
}

void rmCommand(char ** fileNames, enum FileNameMarker specialMarker){
  if (currFsName == NULL){
    printf("ERROR: No filesystem mounted. \n");
    return;
  }

  char * fileName = *fileNames;

  // printf("RM COMMAND: OPENING FILE %s...", currFsName);
  int fs_fd = open(currFsName, O_RDWR);

  while (fileName != NULL){
    struct directory_entry * fileEntry = findDirEntry(fileName, rootDirectory);
    if (fileEntry != NULL){
      int firstBlock = fileEntry->firstBlock;
      int entrySize = fileEntry->size;

      rootDirectory = deleteDirEntry(fileName, rootDirectory);
      int metaDataBlockLocation = findMetaDataLocation(fileName);

      if (metaDataBlockLocation != -1){
        //Remove data files from FAT
        if (entrySize > 0){
          while(firstBlock != defaultVal) {
            int nextBlock = fat[firstBlock];
            fat[firstBlock] = 0;
            firstBlock = nextBlock;
          }
        }
        close(fs_fd);
        fs_fd = open(currFsName, O_RDWR);
        lseek(fs_fd, metaDataBlockLocation, SEEK_SET);
        uint64_t clearZero = 0; //8B --> 64B / 8 = 8 iterations
        for (int i = 0; i < 8; i++){
          write(fs_fd, &clearZero, sizeof(clearZero));
        }
        lseek(fs_fd, metaDataBlockLocation, SEEK_SET);
        int writeSpecialMarker = DeletedEntryAndFile;
        write(fs_fd, &writeSpecialMarker, 1);

      } else {
        printf("ERROR: METADATA CURRUPTION.");
        exit(EXIT_FAILURE);
      }
    } else {
      printf("ERROR: Could not find and rm file %s. Please try again with a valid filename.\n", fileName);
    }
    fileNames++;
    fileName = *fileNames;
  }
  close(fs_fd);
}

void lsCommand(){
  if (currFsName == NULL){
    printf("ERROR: No filesystem mounted. \n");
    return;
  }
  
  // first block number, permissions, size, month, day, time, and name
  // 2 -rw 30000 Nov 7 01:00 up-to-thirty-one-byte-file-name
  struct directory_entry * ptr = rootDirectory;
  while(ptr != NULL){
    char dateTime[20]; //Maybe like 14 instead?
    time_t entryTime = ptr->mtime;
    struct tm * localTime = localtime(&entryTime);
    strftime(dateTime, sizeof(dateTime), "%b %d %H:%M", localTime);
    printf("%d %s %d %s %s \n", ptr->firstBlock, FILE_PERM_TO_STRING[ptr->perm], ptr->size, dateTime, ptr->name);
    ptr = ptr->next;
  }
}

char * lsCommandAllFiles(){
  if (currFsName == NULL){
    printf("ERROR: No filesystem mounted. \n");
    return NULL;
  }
  char * output = (char *) calloc(100, sizeof(char));
  struct directory_entry * ptr = rootDirectory;
  while(ptr != NULL){
    char dateTime[20]; //Maybe like 14 instead?
    time_t entryTime = ptr->mtime;
    struct tm * localTime = localtime(&entryTime);
    strftime(dateTime, sizeof(dateTime), "%b %d %H:%M", localTime);

    char * strBuff = calloc(100, sizeof(char));
    sprintf(strBuff, "%d %s %d %s %s \n", ptr->firstBlock, FILE_PERM_TO_STRING[ptr->perm], ptr->size, dateTime, ptr->name);
    // printf("%d %s %d %s %s \n", ptr->firstBlock, FILE_PERM_TO_STRING[ptr->perm], ptr->size, dateTime, ptr->name);
    output = (char *) realloc(output, 100 + strlen(output) + strlen(strBuff));
    strcat(output, strBuff);
    // printf("4: %s\n", ptr->name);
    ptr = ptr->next;
  }
  return output;
}

char * lsCommandOneFile(char * fileName){
  if (currFsName == NULL){
    printf("ERROR: No filesystem mounted. \n");
    return NULL;
  }
  struct directory_entry * fileEntry = findDirEntry(fileName, rootDirectory);
  if (fileEntry == NULL){
    printf("ERROR: File %s Does Not Exist in File System.\n", fileName);
    return NULL;
  }

  char dateTime[20]; //Maybe like 14 instead?
  time_t entryTime = fileEntry->mtime;
  struct tm * localTime = localtime(&entryTime);
  strftime(dateTime, sizeof(dateTime), "%b %d %H:%M", localTime);

  char * strBuff = calloc(100, sizeof(char)); //= calloc(sizeof(fileEntry->firstBlock) + sizeof(FILE_PERM_TO_STRING[fileEntry->perm]) + sizeof(fileEntry->size) + sizeof(dateTime) + sizeof(fileEntry->name) + 6, sizeof(char));
  sprintf(strBuff, "%d %s %d %s %s \n", fileEntry->firstBlock, FILE_PERM_TO_STRING[fileEntry->perm], fileEntry->size, dateTime, fileEntry->name);
  return strBuff;
}

void cpCommand(char * source, char * dest, int toggler){ //TODO: make toggler into enum
  if (currFsName == NULL) {
    printf("ERROR: No filesystem mounted. \n");
    return;
  }
  if (toggler == 0) { // -h in front of source 
    
    int fd_sourceFile = open(source, O_RDWR);

    if (fd_sourceFile == -1) {
      printf("[INVALID INPUT]: source file not found on host system");
      close (fd_sourceFile);
      return;
    }
    
    int fd_destFile = open(dest, O_RDWR);

    struct stat buf;
    fstat(fd_sourceFile, &buf);
    off_t size = buf.st_size;

    // printf("SIZE OF FILE: %ld\n\n", size);

    if (size > getAmountOfAvailableSpace()) {
      printf("[DATA ERROR]: File too large! Not enough space to copy this data");
      close(fd_destFile);
      close (fd_sourceFile);
      return;
    }

    int sizeSource = size;

    struct directory_entry * dirEntryDest = findDirEntry(dest, rootDirectory);
    
    int sizeDest = sizeSource;
    uint16_t firstBlock = 0;
    time_t curTime = time(NULL);

    enum FileType type = RegularFile;
    enum FilePermissions perm = ReadWritePermissions; 

    int fs_fd = open(currFsName, O_RDWR);

    if (dirEntryDest != NULL) {

      printf("ENTRY ALREADY EXISTS: Overwriting... \n");

      char * outputFileArr[2] = {dest, NULL};
      rmCommand(outputFileArr, DeletedEntryAndFile);
      touchCommand(outputFileArr);
      dirEntryDest = findDirEntry(dest, rootDirectory);
      if (dirEntryDest->firstBlock == 0) {
        firstBlock =  findFirstOpenDataBlockNumber();
      } else {
        firstBlock =  dirEntryDest->firstBlock;
      }
      
      type = dirEntryDest->type;
      perm = dirEntryDest->perm;
      writeMetaDataFileExists(fs_fd, dest, (uint32_t) sizeDest, firstBlock, type, perm, curTime);
    } else {
      firstBlock = findFirstOpenDataBlockNumber();
      int offset = currFatRegionSize + currBlockSizeBytes * (firstBlock - 1);
      clearDataBlock(offset);
      writeMetaData(fs_fd, dest, (uint32_t) sizeDest, firstBlock, type, perm, curTime);
    }

    int numBytesLeft = sizeSource;
    int blockCounter = 0;

    while (numBytesLeft > 0) {
      int nextBlock = findFirstOpenDataBlockNumber();
      fat[firstBlock] = nextBlock;
      fat[nextBlock] = 0xFFFF;
      firstBlock = nextBlock;

      // printf("SIZE OF FILE LEFT: %d\n", numBytesLeft);
      
      char * block = malloc(currBlockSizeBytes * sizeof(char) + 1);
      lseek(fd_sourceFile, currBlockSizeBytes * blockCounter, SEEK_SET);
      read(fd_sourceFile, block, currBlockSizeBytes);

      close(fs_fd); //TODO: Remove... this makes no sense
      fs_fd = open(currFsName, O_RDWR);
      
      int offset = currFatRegionSize + currBlockSizeBytes * (firstBlock - 1);
      clearDataBlock(offset);
      // printf("offset: %X\n", offset);

      lseek(fs_fd, offset, SEEK_SET);

      // printf("%s\n", block);
      write(fs_fd, block, currBlockSizeBytes);
      
      free(block);

      numBytesLeft -=  currBlockSizeBytes;
      blockCounter++;
      
    }
    
    //close(fs_fd);
    close(fd_destFile);
    close (fd_sourceFile);
    
  } else if (toggler == 1) { // -h in front of dest

    struct directory_entry * dirEntry = findDirEntry(source, rootDirectory);

    if (dirEntry == NULL) {
      printf("[INVALID INPUT]: source file not found in the file system.");
      return;
    }

    FILE *fs = fopen(dest, "wb");

    int fd_destFile = fileno(fs);
    
    //int fd_destFile = open(dest, O_RDWR);

    int size = dirEntry->size;

    // printf("SIZE OF FILE: %d\n\n", size);

    int numBytesLeft = size;
    int blockCounter = 0;
    
    uint16_t firstBlock = dirEntry->firstBlock;

    int fs_fd = open(currFsName, O_RDWR);
    // printf("%d\n", fs_fd);
    
    while (numBytesLeft > 0) {

      // printf("SIZE OF FILE LEFT: %d\n", numBytesLeft);
      
      char * block = malloc(currBlockSizeBytes * sizeof(char) + 1);

      close(fs_fd); //TODO: Remove... this makes no sense
      fs_fd = open(currFsName, O_RDWR);
      // printf("%d\n", fs_fd);
      
      
      int offset = currFatRegionSize + currBlockSizeBytes * (firstBlock - 1);
      
      // printf("offset: %X\n", offset);

      lseek(fs_fd, offset, SEEK_SET);

      read(fs_fd, block, currBlockSizeBytes);

      // printf("%s\n", block);
      

      //close(fd_destFile); //TODO: Remove... this makes no sense
      //fd_destFile = open(currFsName, O_RDWR);
      // printf("%d\n", fd_destFile);
      
      lseek(fd_destFile, currBlockSizeBytes * blockCounter, SEEK_SET);
      write(fd_destFile, block, currBlockSizeBytes);
      
      free(block);

      numBytesLeft -=  currBlockSizeBytes;
      blockCounter++;
      
      firstBlock = fat[firstBlock];
      break;
    }
    
    close(fs_fd);
    close(fd_destFile);
    //free(fs);
    
  } else { // no -h present in given command
    struct directory_entry * dirEntrySource = findDirEntry(source, rootDirectory);
    if (dirEntrySource == NULL) {
      printf("[INVALID INPUT]: source file not found in the file system.\n");
      return;
    }

    int sizeSource = dirEntrySource->size;
    uint16_t firstBlockSource = dirEntrySource->firstBlock;

    struct directory_entry * dirEntryDest = findDirEntry(dest, rootDirectory);
    
    int sizeDest = sizeSource;
    uint16_t firstBlockDest = 0;
    time_t curTime = time(NULL);

    enum FileType type = RegularFile;
    enum FilePermissions perm = ReadWritePermissions; 

    int fs_fd = open(currFsName, O_RDWR);

    if (dirEntryDest != NULL) {

      printf("ENTRY ALREADY EXISTS: Overwriting... \n");

      char * outputFileArr[2] = {dest, NULL};
      rmCommand(outputFileArr, DeletedEntryAndFile);
      touchCommand(outputFileArr);
      dirEntryDest = findDirEntry(dest, rootDirectory);
      if (dirEntryDest->firstBlock == 0) {
        firstBlockDest =  findFirstOpenDataBlockNumber();
        int offset = currFatRegionSize + currBlockSizeBytes * (firstBlockDest - 1);
        clearDataBlock(offset);
      } else {
        firstBlockDest =  dirEntryDest->firstBlock;
      }
      
      type = dirEntryDest->type;
      perm = dirEntryDest->perm;
      writeMetaDataFileExists(fs_fd, dest, (uint32_t) sizeDest, firstBlockDest, type, perm, curTime);
    } else {
      firstBlockDest = findFirstOpenDataBlockNumber();
      int offset = currFatRegionSize + currBlockSizeBytes * (firstBlockDest - 1);
      clearDataBlock(offset);
      writeMetaData(fs_fd, dest, (uint32_t) sizeDest, firstBlockDest, type, perm, curTime);
    }

    int numBytesLeft = sizeSource;
    int blockCounter = 0;

    while (numBytesLeft > 0) {
      int nextBlock = findFirstOpenDataBlockNumber();
      fat[firstBlockDest] = nextBlock;
      fat[nextBlock] = 0xFFFF;
      firstBlockDest = nextBlock;

      // printf("SIZE OF FILE LEFT: %d\n", numBytesLeft);
      
      char * block = malloc(currBlockSizeBytes * sizeof(char) + 1);

      close(fs_fd); //TODO: Remove... this makes no sense
      fs_fd = open(currFsName, O_RDWR);
      
      int offset = currFatRegionSize + currBlockSizeBytes * (firstBlockSource - 1);
      lseek(fs_fd, offset, SEEK_SET);
      read(fs_fd, block, currBlockSizeBytes);

      
      
      offset = currFatRegionSize + currBlockSizeBytes * (firstBlockDest - 1);
      clearDataBlock(offset);
      // printf("offset: %X\n", offset);

      lseek(fs_fd, offset, SEEK_SET);

      // printf("%s\n", block);
      write(fs_fd, block, currBlockSizeBytes);
      
      free(block);

      numBytesLeft -=  currBlockSizeBytes;
      blockCounter++;

      firstBlockSource = fat[firstBlockSource];
    }

    close(fs_fd);
  }
}


void writeMetaDataFileExists(int fs_fd, char * fileName, uint32_t size, uint16_t firstBlock, enum FileType type, enum FilePermissions perm, time_t curTime) { //TODO: strict type the parameters before writing + lseek to correct location.
  
  rootDirectory = updateDirEntry(NULL, &size, &firstBlock, NULL, NULL, &curTime, fileName, rootDirectory);
  
  int mdBlockLocation = findMetaDataLocation(fileName);

  if (mdBlockLocation != -1){
    lseek(fs_fd, mdBlockLocation, SEEK_SET);
    uint64_t clearZero = 0; //8B --> 64B / 8 = 8 iterations
    for (int i = 0; i < 8; i++){
      write(fs_fd, &clearZero, sizeof(clearZero));
    }

    lseek(fs_fd, mdBlockLocation, SEEK_SET);
    write(fs_fd, fileName, strlen(fileName)); //
    lseek(fs_fd, mdBlockLocation + 32, SEEK_SET);
    
    uint32_t writeSize = size;
    write(fs_fd, &writeSize, sizeof(writeSize)); //size
    
    uint16_t writeFirstBlock = firstBlock;
    write(fs_fd, &writeFirstBlock, sizeof(writeFirstBlock)); //firstBlock
    
    uint8_t writeType = type;
    write(fs_fd, &writeType, sizeof(writeType)); //type

    uint8_t writePerm = perm;
    write(fs_fd, &writePerm, sizeof(writePerm)); //perm

    time_t writeCurTime = curTime;
    write(fs_fd, &writeCurTime, sizeof(writeCurTime)); //mtime
  } else{
    printf("Creating a new directory data block...\n");
    int blockNumIndex = 1;
    int updatedDataRegion = 0;

    //1) identify block number of the end of the directory ( oldEndOfDirectoryBlockNumber ) [HELPER FUNCTION]
    int eodDataRegion = findEODDataRegion();
    // printf("EOD Data Region Block Num: %d\n", eodDataRegion);
    while (blockNumIndex < curTotNumFatEntries && updatedDataRegion == 0){
      // printf("Iteration %d / %d (%f)\n", blockNumIndex + 1, curTotNumFatEntries,  ((float) (blockNumIndex + 1) / (float) curTotNumFatEntries));
      // printf("Curr Fat Entry fat[%d] = %d\n", blockNumIndex, fat[blockNumIndex]);
      if (fat[blockNumIndex] == 0) {

        // 2) set fat[blockNumber] = 0xFFFF
        fat[blockNumIndex] = defaultVal;
        // 3) set fat[eodBlock] = blockNumber
        fat[eodDataRegion] = blockNumIndex;
        // 4) lseek to the new blockNumber in DATA region

        int blockStartNumber = currFatRegionSize + (blockNumIndex - 1) * currBlockSizeBytes;

        // printf("Location of new Dir Block: [%d + %d * %d ] = %d\n", currFatRegionSize, blockNumIndex - 1, currBlockSizeBytes, blockStartNumber);
        
        close(fs_fd); //TODO: Remove... this makes no sense
        fs_fd = open(currFsName, O_RDWR);

        lseek(fs_fd, blockStartNumber, SEEK_SET);
        uint64_t clearZero = 0; //8B --> 64B / 8 = 8 iterations
        for (int i = 0; i < 8; i++){
          write(fs_fd, &clearZero, sizeof(clearZero));
        }

        lseek(fs_fd, blockStartNumber, SEEK_SET);
        write(fs_fd, fileName, strlen(fileName)); //name

        lseek(fs_fd, blockStartNumber + 32, SEEK_SET);
        
        uint32_t writeSize = size;
        write(fs_fd, &writeSize, sizeof(writeSize)); //size
        
        uint16_t writeFirstBlock = firstBlock;
        write(fs_fd, &writeFirstBlock, sizeof(writeFirstBlock)); //firstBlock
        
        uint8_t writeType = type;
        write(fs_fd, &writeType, sizeof(writeType)); //type

        uint8_t writePerm = perm;
        write(fs_fd, &writePerm, sizeof(writePerm)); //perm

        time_t writeCurTime = curTime;
        write(fs_fd, &writeCurTime, sizeof(writeCurTime)); //mtime

        updatedDataRegion = 1;
      }
      blockNumIndex++;
    }
  }
}


void writeMetaData(int fs_fd, char * fileName, uint32_t size, uint16_t firstBlock, enum FileType type, enum FilePermissions perm, time_t curTime) { //TODO: strict type the parameters before writing + lseek to correct location.
  
  rootDirectory = insertNewDirEntry(fileName, size, firstBlock, type, perm, curTime, rootDirectory);
  
  int mdBlockLocation = findOpenMetaDataLocation();

  if (mdBlockLocation != -1){
    lseek(fs_fd, mdBlockLocation, SEEK_SET);
    uint64_t clearZero = 0; //8B --> 64B / 8 = 8 iterations
    for (int i = 0; i < 8; i++){
      write(fs_fd, &clearZero, sizeof(clearZero));
    }

    lseek(fs_fd, mdBlockLocation, SEEK_SET);
    write(fs_fd, fileName, strlen(fileName)); //
    lseek(fs_fd, mdBlockLocation + 32, SEEK_SET);
    
    uint32_t writeSize = size;
    write(fs_fd, &writeSize, sizeof(writeSize)); //size
    
    uint16_t writeFirstBlock = firstBlock;
    write(fs_fd, &writeFirstBlock, sizeof(writeFirstBlock)); //firstBlock
    
    uint8_t writeType = type;
    write(fs_fd, &writeType, sizeof(writeType)); //type

    uint8_t writePerm = perm;
    write(fs_fd, &writePerm, sizeof(writePerm)); //perm

    time_t writeCurTime = curTime;
    write(fs_fd, &writeCurTime, sizeof(writeCurTime)); //mtime
  } else{
    printf("Creating a new directory data block...\n");
    int blockNumIndex = 1;
    int updatedDataRegion = 0;

    //1) identify block number of the end of the directory ( oldEndOfDirectoryBlockNumber ) [HELPER FUNCTION]
    int eodDataRegion = findEODDataRegion();
    // printf("EOD Data Region Block Num: %d\n", eodDataRegion);
    while (blockNumIndex < curTotNumFatEntries && updatedDataRegion == 0){
      // printf("Iteration %d / %d (%f)\n", blockNumIndex + 1, curTotNumFatEntries,  ((float) (blockNumIndex + 1) / (float) curTotNumFatEntries));
      // printf("Curr Fat Entry fat[%d] = %d\n", blockNumIndex, fat[blockNumIndex]);
      if (fat[blockNumIndex] == 0) {

        // 2) set fat[blockNumber] = 0xFFFF
        fat[blockNumIndex] = defaultVal;
        // 3) set fat[eodBlock] = blockNumber
        fat[eodDataRegion] = blockNumIndex;
        // 4) lseek to the new blockNumber in DATA region

        int blockStartNumber = currFatRegionSize + (blockNumIndex - 1) * currBlockSizeBytes;

        // printf("Location of new Dir Block: [%d + %d * %d ] = %d\n", currFatRegionSize, blockNumIndex - 1, currBlockSizeBytes, blockStartNumber);
        
        close(fs_fd); //TODO: Remove... this makes no sense
        fs_fd = open(currFsName, O_RDWR);

        lseek(fs_fd, blockStartNumber, SEEK_SET);
        uint64_t clearZero = 0; //8B --> 64B / 8 = 8 iterations
        for (int i = 0; i < 8; i++){
          write(fs_fd, &clearZero, sizeof(clearZero));
        }

        lseek(fs_fd, blockStartNumber, SEEK_SET);
        write(fs_fd, fileName, strlen(fileName)); //name

        lseek(fs_fd, blockStartNumber + 32, SEEK_SET);
        
        uint32_t writeSize = size;
        write(fs_fd, &writeSize, sizeof(writeSize)); //size
        
        uint16_t writeFirstBlock = firstBlock;
        write(fs_fd, &writeFirstBlock, sizeof(writeFirstBlock)); //firstBlock
        
        uint8_t writeType = type;
        write(fs_fd, &writeType, sizeof(writeType)); //type

        uint8_t writePerm = perm;
        write(fs_fd, &writePerm, sizeof(writePerm)); //perm

        time_t writeCurTime = curTime;
        write(fs_fd, &writeCurTime, sizeof(writeCurTime)); //mtime

        updatedDataRegion = 1;
      }
      blockNumIndex++;
    }
  }
}

// int 0 = SUCCESS, 1 = FAILURE --> Note: We ignore redundant permission adds / removals and continue with the rest 
void chmodCommand(char * fileName, enum PermissionChangeAction change){
  if (currFsName == NULL){
    printf("ERROR: No filesystem mounted. \n");
    return;
  }
  struct directory_entry * dirEntry = findDirEntry(fileName, rootDirectory);

  if (dirEntry == NULL){
    printf("ERROR: FILE %s DOES NOT EXIST IN FILESYSTEM.\n", fileName);
  } else {
    int readPerm = 0;
    int writePerm = 0;
    int executePerm = 0;
    //Populate Existing Permissions
    switch (dirEntry->perm) {
    case WriteOnlyPermissions:
      writePerm = 1;
      break;
    case ReadOnlyPermissions:
      readPerm = 1;
      break;
    case ReadExecutablePermissions:
      readPerm = 1;
      executePerm = 1;
      break;
    case ReadWritePermissions:
      readPerm = 1;
      writePerm = 1;
      break;
    case ReadWriteExecutablePermissions:
      readPerm = 1;
      writePerm = 1;
      executePerm = 1;
      break;

    default:
      break;
    }

    switch (change) {
    case AddReadPerm:
      readPerm = 1;
      break;
    case RmReadPerm:
      if (executePerm != 1){
        readPerm = 0;
      } else {
        printf("ERROR: Cannot Remove File Read Permissions If Executable.\n");
      }
      break;
    case AddWritePerm:
      writePerm = 0;
      break;
    case RmWritePerm:
      writePerm = 0;
      break;
    case AddExecutePerm:
      if (readPerm == 1){
        executePerm = 1;
      } else {
        printf("ERROR: Cannot Add Executable Permissions If File is Not Readable.\n");
      }
      break;
    case RmExecutePerm:
      executePerm = 0;
      break;
    case AddReadWritePerm:
      readPerm = 1;
      writePerm = 1;
      break;
    case RmReadWritePerm:
      writePerm = 0;
      if (executePerm != 1){
        readPerm = 0;
      } else {
        printf("ERROR: Cannot Remove File Read Permissions If Executable.\n");
      }
      break;
    case AddWriteExecutePerm:
      writePerm = 1;
      if (readPerm == 1){
        executePerm = 1;
      } else {
        printf("ERROR: Cannot Add Executable Permissions If File is Not Readable.\n");
      }
      break;
    case RmWriteExecutePerm:
      writePerm = 0;
      executePerm = 0;
      break;
    case AddReadExecutePerm:
      /* code */
      readPerm = 1;
      executePerm = 1;
      break;
    case RmReadExecutePerm:
      readPerm = 0;
      executePerm = 0;
      break;
    case AddReadWriteExecutePerm:
      readPerm = 1;
      writePerm = 1;
      executePerm = 1;
      break;
    case RmReadWriteExecutePerm:
      readPerm = 0;
      writePerm = 0;
      executePerm = 0;
      break;
    default:
      printf("ERROR: Execution Change Failure.");
      break;
    }


    dirEntry->perm = writePerm * 2 + readPerm * 4 + executePerm * 1;

    //Update Metadata
    int fs_fd = open(currFsName, O_RDWR);
    int fileMDLocation = findMetaDataLocation(dirEntry->name);
    lseek(fs_fd, fileMDLocation + 39, SEEK_SET); //32B + 4B + 2B + 1B
    uint8_t permPointer = dirEntry->perm;
    // printf("WRITING VALUE: %d [%X]\n", permPointer, permPointer);
    write(fs_fd, &permPointer, sizeof(permPointer));
  }
  // printf("CHMOD PRINT START-----\n");
  // printLinkedList(rootDirectory);
  // printf("CHMOD PRINT END-----\n\n");
}

// int interactiveFinished = 0;
// void catSignalHandler(int signum) {
// 	if (signum == SIGINT) {
//     interactiveFinished = 1;
//     write (STDERR_FILENO, "\nControl-C SIGNAL\n", 19); //Comment out
//   }
// }
// char * catInteractive() { // TODO: Exits on Control-D? (https://piazza.com/class/ksasy2cuwdv2fd?cid=1086)
//   char * outputString = (char *) calloc(currDataRegionSize, sizeof(char)); //TODO: Free

//   if(signal(SIGINT, catSignalHandler) == SIG_ERR || siginterrupt(SIGINT, 1) == -1){ //siginterrupt -> 1 = interrupt, 0 = restart
//     perror("Signal SIGING catInteractive()");
//     exit(EXIT_FAILURE);
//   }

//   char * readBuff = (char *) calloc(100, sizeof(char));
//   while(interactiveFinished == 0){
//     read(STDIN_FILENO, readBuff, sizeof(readBuff));
//     if (interactiveFinished == 0){
//       strcat(outputString, readBuff);
//     }
//     memset(readBuff, 0, 100);
//   }
//   free(readBuff);
//   return outputString;
// }

char * catInteractive() { // TODO: Exits on Control-D? (https://piazza.com/class/ksasy2cuwdv2fd?cid=1086)
  char * outputString = (char *) calloc(4096, sizeof(char));
  char * readBuff = (char *) calloc(100, sizeof(char));
  while(read(STDIN_FILENO, readBuff, 100) > 0){
    strcat(outputString, readBuff);
    memset(readBuff, 0, 100);
    if (outputString[strlen(outputString) - 1] != '\n'){
      printf("\n");
      break;
    }
  }
  free(readBuff);
  return outputString;
}

char * catNonInteractive(char ** fileNames){
  char * outputString = NULL;
  while(fileNames != NULL && *fileNames != NULL){
    char * fileName = *fileNames;
    struct directory_entry * fileEntry = findDirEntry(fileName, rootDirectory);
    // printf("File Name: %s\n\n", fileName);
    if (fileEntry != NULL && fileEntry->size != 0) {
      int dataBlockNum = fileEntry->firstBlock;
      while(dataBlockNum != defaultVal){
        int dataLoc = currFatRegionSize + (dataBlockNum - 1) * currBlockSizeBytes;

        char * blockData = (char *) calloc(currBlockSizeBytes, sizeof(char));
        safeRead(dataLoc, blockData, currBlockSizeBytes);
        // printf("[%d] NEW DATA: %s\n", dataBlockNum, blockData);

        if (outputString == NULL){
          // printf("HERE 1 %lu\n", strlen(blockData) + 1);
          outputString = (char *) malloc(strlen(blockData) + 1);
          strcpy(outputString, blockData);
        } else {
          // printf("HERE 2 %lu\n", strlen(outputString) + strlen(blockData) + 1);
          outputString = (char *) realloc(outputString, strlen(outputString) + strlen(blockData) + 1);
          strcat(outputString, blockData);
        }
        // printf("[%d] FINAL DATA: %s\n\n", dataBlockNum, outputString);

        dataBlockNum = fat[dataBlockNum];
      }
    } else {
      printf("ERROR: File %s does not exist in filesystem.\n", fileName);
      return NULL;
    }

    fileNames++;
  }
  return outputString;
}

void catCommand(char ** fileNames, char * outputFile, enum CommandFlag commandFlag) {
  if (currFsName == NULL){
    printf("ERROR: No filesystem mounted. \n");
    return;
  }
  if ((outputFile != NULL && commandFlag == PrintFile) || (outputFile == NULL && commandFlag != PrintFile)){
    printf("ERROR: CAT INCORRECT SYNTAX.\n");
    return;
  }
  
  char * outputString = NULL;

  // 1.) Get Output String
  if (fileNames == NULL){
    // printf("Interactive..\n");
    outputString = catInteractive();
  } else {
    // printf("Non-Interactive..\n");
    outputString = catNonInteractive(fileNames);
  }
  // interactiveFinished = 0;

  if (outputString == NULL){
    printf("CAT ERROR: ONE OF THE FILES DOES NOT EXIST.\n");
    return;
  }

  char * outputStringPtr = outputString;

  printf("CAT COMMAND: %s\n", outputStringPtr);


  // 2.) Write to Ouput File
  // printf("CHECK HERE FILE NAME FS: %s\n", currFsName);
  // int fs_fd = open(currFsName, O_RDWR);
  if (commandFlag == AppendFile){
    printf("APPEND OUTPUT ...\n");
    if (strlen(outputStringPtr) > getAmountOfAvailableSpace()){
      printf("ERROR: Not Enough Space for the cat input.\n");
      return;
    }
    struct directory_entry * fileDirEntry = findDirEntry(outputFile, rootDirectory);
    if (fileDirEntry == NULL){
      char * touchFileArr[2] = {outputFile, NULL};
      touchCommand(touchFileArr);
      fileDirEntry = findDirEntry(outputFile, rootDirectory);
    }
    // File is empty
    if (fileDirEntry->size == 0) { //TODO: Check if there's enough available space in data region
      int newOpenDataBlock = findFirstOpenDataBlockNumber();
      fat[newOpenDataBlock] = defaultVal;
      fileDirEntry->firstBlock = newOpenDataBlock;

      clearDataBlock((newOpenDataBlock - 1) * currBlockSizeBytes + currFatRegionSize);
      // printf("New First Block: %d \n", fileDirEntry->firstBlock);
    }
    fileDirEntry->size += strlen(outputString); 


    //Update Metadata
    int mdLoc = findMetaDataLocation(outputFile);
    uint32_t writeSize = fileDirEntry->size;
    safeWrite(mdLoc + 32, &writeSize, sizeof(writeSize));
    uint16_t writeFirstBlock = fileDirEntry->firstBlock;
    safeWrite(mdLoc + 32 + 4, &writeFirstBlock, sizeof(writeFirstBlock));
    time_t curTime = time(NULL);
    safeWrite(mdLoc + 32 + 4 + 2 + 1 + 1, &curTime, sizeof(curTime));
    fileDirEntry->mtime = curTime;

    // printf("[@ %d] Write Size: %d [%X], First Block: %d [%X]\n", mdLoc, writeSize, writeSize, writeFirstBlock, writeFirstBlock);
    

    //Find last data block
    int curDataBlock = fileDirEntry->firstBlock;
    while(fat[curDataBlock] != defaultVal){
      curDataBlock = fat[curDataBlock];
    }
    int dataLoc = currFatRegionSize + (curDataBlock - 1) * currBlockSizeBytes;

    char * fileBuff = (char *) malloc(currBlockSizeBytes);
    safeRead(dataLoc, fileBuff, currBlockSizeBytes);
    // printf("READ 1 FD: %d\n", fsFd);

    int openSpaceInDataBlock = currBlockSizeBytes - strlen(fileBuff);
    int remainingToWrite = strlen(outputStringPtr);
    
    //Open Space in Existing Block
    if(openSpaceInDataBlock > strlen(outputStringPtr)) {
      // printf("\n\nWRITING %s TO BLOCK %d, dataLoc %d [%d + %d]\n\n", outputStringPtr, curDataBlock, (int) (dataLoc + strlen(fileBuff)), dataLoc, (int) strlen(fileBuff));

      int writeBytes = min(openSpaceInDataBlock, remainingToWrite);
      safeWrite(dataLoc + strlen(fileBuff), outputStringPtr, writeBytes);
      
      outputStringPtr += writeBytes;
      remainingToWrite -= writeBytes;
    }

    //New Blocks
    while(remainingToWrite > 0){
      // printf("REMAINING JAWN\n");
      int newBlock = findFirstOpenDataBlockNumber();
      fat[curDataBlock] = newBlock;
      fat[newBlock] = defaultVal;
      curDataBlock = newBlock;
      clearDataBlock((newBlock - 1) * currBlockSizeBytes + currFatRegionSize);

      dataLoc = currFatRegionSize + (curDataBlock - 1) * currBlockSizeBytes;
      int writeBytes = min(currBlockSizeBytes, remainingToWrite);
      safeWrite(dataLoc, outputStringPtr, writeBytes);

      remainingToWrite -= writeBytes;
      outputStringPtr += writeBytes;
    }

    // printf("NEW FILE SIZE: %d, NEW BLOCK LOCATION: %d \n", fileDirEntry->size, fileDirEntry->firstBlock);

    free(fileBuff);
  } else if (commandFlag == OverwriteFile){
    printf("Overwrite...\n");

    char * outputFileArr[2] = {outputFile, NULL};
    struct directory_entry * fileDirEntry = findDirEntry(outputFile, rootDirectory);
    if (fileDirEntry != NULL) {
      rmCommand(outputFileArr, DeletedEntryAndFile);
    }
    touchCommand(outputFileArr);
    fileDirEntry = findDirEntry(outputFile, rootDirectory);
    
    //Find new data block + Update FAT
    int newOpenDataBlock = findFirstOpenDataBlockNumber();
    fat[newOpenDataBlock] = defaultVal;
    fileDirEntry->firstBlock = newOpenDataBlock;
    fileDirEntry->size += strlen(outputString); 
    clearDataBlock((newOpenDataBlock - 1) * currBlockSizeBytes + currFatRegionSize);

    //Update Metadata
    int mdLoc = findMetaDataLocation(outputFile);
    uint32_t writeSize = fileDirEntry->size;
    safeWrite(mdLoc + 32, &writeSize, sizeof(writeSize));
    uint16_t writeFirstBlock = fileDirEntry->firstBlock;
    safeWrite(mdLoc + 32 + 4, &writeFirstBlock, sizeof(writeFirstBlock));
    time_t curTime = time(NULL);
    safeWrite(mdLoc + 32 + 4 + 2 + 1 + 1, &curTime, sizeof(curTime));
    fileDirEntry->mtime = curTime;

    int remainingToWrite = strlen(outputStringPtr);
    int curDataBlock = fileDirEntry->firstBlock;
    int dataLoc = currFatRegionSize + (curDataBlock - 1) * currBlockSizeBytes;

    //New Blocks
    while(remainingToWrite > 0){
      if (curDataBlock != newOpenDataBlock){
        int newBlock = findFirstOpenDataBlockNumber();
        fat[curDataBlock] = newBlock;
        fat[newBlock] = defaultVal;
        curDataBlock = newBlock;
      }

      dataLoc = currFatRegionSize + (curDataBlock - 1) * currBlockSizeBytes;
      clearDataBlock(dataLoc);
      int writeBytes = min(currBlockSizeBytes, remainingToWrite);
      safeWrite(dataLoc, outputStringPtr, writeBytes);

      remainingToWrite -= writeBytes;
      outputStringPtr = outputStringPtr + writeBytes;
    }
  } else if(commandFlag == PrintFile){
    printf("Print...\n");
    printf("%s\n", outputStringPtr);
  } else {
    printf("NO OUTPUT FLAG... ERROR \n");
  }
  
  free(outputString);
}