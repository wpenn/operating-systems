#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "fsHandler.h"
#include "directoryEntryManager.h"
#include "SystemCalls.h"



/**
 * ===============================================
 * FD TABLE HANDLER
 * ===============================================
 */

int CUR_AVAILABLE_FD = 3; //STDIN = 0, STDOUT = 1, STDERR = 2
struct fdTableEntry * fdTable = NULL;

int insertNewFD(char * fileName, enum Mode mode){
    struct fdTableEntry * newFdEntry = (struct fdTableEntry *) malloc(sizeof(struct fdTableEntry));
    newFdEntry->fileName = fileName;
    newFdEntry->mode = mode;

    newFdEntry->seekLocation = 0;
    newFdEntry->fd = CUR_AVAILABLE_FD++;

    newFdEntry->next = fdTable;

    fdTable = newFdEntry;

    return newFdEntry->fd;
}

struct fdTableEntry * getFd(int fd){
    struct fdTableEntry * curFdEntry = fdTable;
    while(curFdEntry != NULL){
        if (curFdEntry->fd == fd){
            return curFdEntry;
        }
        curFdEntry = curFdEntry->next;
    }
    return NULL;
}

struct fdTableEntry * getFdByNameMode(char * fileName, enum Mode mode){
    struct fdTableEntry * curFdEntry = fdTable;
    while(curFdEntry != NULL){
        if (curFdEntry->fileName == fileName && curFdEntry->mode == mode){
            return curFdEntry;
        }
        curFdEntry = curFdEntry->next;
    }
    return NULL;
}

int deleteFd(int fd){
    struct fdTableEntry * curFdEntry = fdTable;
    struct fdTableEntry * prevFdEntry = NULL;
    if (fdTable == NULL){
        printf("DeleteFd ERROR: FD DOES NOT EXIST IN TABLE\n");
        return -1;
    }

    while(curFdEntry->fd != fd){
        if(curFdEntry->next ==  NULL){
            return -1;
        } else {
            prevFdEntry = curFdEntry;
            curFdEntry = curFdEntry->next;
        }
    }

    if(curFdEntry == fdTable){
        fdTable = fdTable->next;
    } else {
        prevFdEntry->next = curFdEntry->next;
    }
    return 0;
}

int deleteOneByFileName(char * fileName){
    struct fdTableEntry * curFdEntry = fdTable;
    struct fdTableEntry * prevFdEntry = NULL;
    if (fdTable == NULL){
        printf("DeleteFd ERROR: FD DOES NOT EXIST IN TABLE\n");
        return -1;
    }

    while(curFdEntry->fileName != fileName){
        if(curFdEntry->next ==  NULL){
            return -1;
        } else {
            prevFdEntry = curFdEntry;
            curFdEntry = curFdEntry->next;
        }
    }

    if(curFdEntry == fdTable){
        fdTable = fdTable->next;
    } else {
        prevFdEntry->next = curFdEntry->next;
    }
    return 0;
}

int deleteByFileName(char * fileName){
    while (deleteOneByFileName(fileName) != -1);
    return 1;
}

void updateFd(
    int * fd,
    char ** fileName,
    enum Mode * mode,
    int * seekLocation,
    int fdTarget
) {
    struct fdTableEntry * targetFdEntry = getFd(fdTarget);
    if (targetFdEntry == NULL){
        printf("UpdateFd ERROR: COULD NOT FIND TARGET FD %d", fdTarget);
    } else {
        if (fd != NULL){
            targetFdEntry->fd = *fd;
        }
        if (fileName != NULL){
            targetFdEntry->fileName = *fileName;
        }
        if (mode != NULL){
            targetFdEntry->mode = *mode;
        }
        if (seekLocation != NULL){
            targetFdEntry->seekLocation = *seekLocation;
        }
    }
}

void printFdTable(){
    struct fdTableEntry * curFdEntry = fdTable;
    while(curFdEntry != NULL){
        printf("FD: %d || NAME: %s || MODE: %d || SEEK LOCATION: %d \n", curFdEntry->fd, curFdEntry->fileName, curFdEntry->mode, curFdEntry->seekLocation);
        curFdEntry = curFdEntry->next;
    }
}


/**
 * ===============================================
 * SYSTEM CALLS
 * ===============================================
 */

int f_open(char * fname, enum Mode mode) {
    // Root Directory
    struct directory_entry * rootDirectory = getHead();
    char * fileArr[2] = {fname, NULL};

    if (mode == F_WRITE){
        if(getFdByNameMode(fname, F_WRITE) != NULL){
            return -1;
        }
        if (findDirEntry(fname, rootDirectory) != NULL) {
            rmCommand(fileArr, 0); //Doesn't matter what special marker it is, just using to clear file
        }
        touchCommand(fileArr);
        return insertNewFD(fname, mode);
    } else if (mode == F_READ){
        if (findDirEntry(fname, rootDirectory) == NULL) {
            return -1;
        }
        return insertNewFD(fname, mode);
    } else if (mode == F_APPEND){ //TODO: What happens when the end of file changes (standalone functions vs. below)?
        int newFd = insertNewFD(fname, mode);
        struct directory_entry * fileEntry = findDirEntry(fname, rootDirectory);
        if (fileEntry == NULL){
            touchCommand(fileArr);
        } else {
            int newSeekLoc = fileEntry->size;
            updateFd(NULL, NULL, NULL, &newSeekLoc, newFd); //FD points to end of file
        }
        return newFd;
    }
	return -1;
}

//On return, f_read returns the number of bytes read, 0 if EOF is reached, or a negative number on error.
int f_read(int fd, int n, char * buf) {
    if (fd == STDERR_FILENO || fd == STDOUT_FILENO){
        return -1;
    }
    if(fd == STDIN_FILENO){
        return read(fd, buf, n);
    }
    struct fdTableEntry * fdEntry = getFd(fd);
    if(fdEntry == NULL){
        return -1;
    }
    int output = getAllFileData(buf, fdEntry->fileName, fdEntry->seekLocation, n);
    if (output >= 0){
        fdEntry->seekLocation += n;
    }
    return output;
}

//Note: n <= len(str)
int f_write(int fd, char * str, int n){
    if(n > strlen(str)){
        // return -1;
        n = strlen(str);
    }

    if (fd == STDIN_FILENO){
        return -1;
    }

    if(fd == STDOUT_FILENO || fd == STDERR_FILENO){
        return write(fd, str, n);
    }
    struct fdTableEntry * fdEntry = getFd(fd);
    if(fdEntry == NULL){
        return -1;
    }
    if (fdEntry->mode == F_READ){
        return -1;
    }
    int writeValue = writeToFileData(str, fdEntry->fileName, fdEntry->seekLocation, n);
    fdEntry->seekLocation += n;
    return writeValue;
}

int f_close(int fd){
    return deleteFd(fd);
}

void f_unlink(char * fname){
    int fileInUseByAnotherProcess = 0; //TODO: IMPLEMENT
    if (!fileInUseByAnotherProcess){
        deleteByFileName(fname);
        char * fileArr[2] = {fname, NULL};
        rmCommand(fileArr, DeletedEntryAndFile); // As Opposed to DeletedEntryAndFileInUse
    }
}

void f_lseek(int fd, int offset, enum SeekFlag whence){
    struct fdTableEntry * fdEntry = getFd(fd);
    if (fdEntry == NULL){
        printf("ERROR: FD %d Does Not Exist in FD Table.\n", fd);
    }
    struct directory_entry * fileEntry = findDirEntry(fdEntry->fileName, getHead());
    int newLocation = -1;
    if (whence == F_SEEK_SET){
        newLocation = offset;
    } else if (whence == F_SEEK_CUR){
        newLocation = offset + fdEntry->seekLocation;
    } else if (whence == F_SEEK_END) {
        newLocation = fileEntry->size + offset;
    } else {
        printf("ERROR: Whence Variable Incorrect.\n");
        return;
    }
    updateFd(NULL, NULL, NULL, &newLocation, fd);  
} 

char * f_ls(char *filename){
    if (filename == NULL){
        return lsCommandAllFiles();
    } else {
        return lsCommandOneFile(filename);
    }
    return NULL;
}

void f_touch(char ** fileNames){
    touchCommand(fileNames);
}

void f_mv(char ** argv){
    printf("Source: %s || Dest: %s\n", argv[0], argv[1]);
    mvCommand(argv[0], argv[1]);
}

void f_rm(char ** fileNames){
    rmCommand(fileNames, DeletedEntryAndFile);
}

void f_cp(char ** argv){
    cpCommand(argv[0], argv[1], 2);
}

void f_chmod(char ** argv){
    char * permission = argv[1];
    char * fileName = argv[2];

    enum PermissionChangeAction change = AddReadPerm;
    if (!strcmp(permission, "+r")) {
        change = AddReadPerm;
    } else if (!strcmp(permission, "-r")) {
        change = RmReadPerm;
    } else if (!strcmp(permission, "+w")) {
        change = AddWritePerm;
    } else if (!strcmp(permission, "-w")) {
        change = RmWritePerm;
    } else if (!strcmp(permission, "+x")) {
        change = AddExecutePerm;
    } else if (!strcmp(permission, "-x")) {
        change = RmExecutePerm;
    } else if (!strcmp(permission, "+rw")) {
        change = AddReadWritePerm;
    } else if (!strcmp(permission, "-rw")) {
        change = RmReadWritePerm;
    } else if (!strcmp(permission, "+wx")) {
        change = AddWriteExecutePerm;
    } else if (!strcmp(permission, "-wx")) {
        change = RmWriteExecutePerm;
    } else if (!strcmp(permission, "+rx")) {
        change = AddReadExecutePerm;
    } else if (!strcmp(permission, "-rx")) {
        change = RmReadExecutePerm;
    } else if (!strcmp(permission, "+rwx")) {
        change = AddReadWriteExecutePerm;
    } else if (!strcmp(permission, "-rwx")) {
        change = RmReadWriteExecutePerm;
    } else {
        printf("Invalid permission input.\n");
        return;
    }
    chmodCommand(fileName, change);
}

void f_mkfs(char * filesystemName, int blocksInFat, int blockSizeConfig){
    mkfs_command(filesystemName, blocksInFat, blockSizeConfig);
}

void f_mount(char * filesystemName){
    mountFsCommand(filesystemName);
}