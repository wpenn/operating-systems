#include <stdlib.h>
#include <stdint.h>

#ifndef PARENT
#define PARENT

enum FileNameMarker{
    EOD = 0,
    DeletedEntryAndFile = 1,
    DeletedEntryAndFileInUse = 2
};

enum FileType{
    UnknownFile = 0,
    RegularFile = 1,
    DirectoryFile = 2,
    SymbolicLink = 4
};

enum FilePermissions {
    NoFilePermissions = 0,
    WriteOnlyPermissions = 2,
    ReadOnlyPermissions = 4,
    ReadExecutablePermissions = 5,
    ReadWritePermissions = 6,
    ReadWriteExecutablePermissions = 7
};

enum PermissionChangeAction {
    AddReadPerm = 4,
    RmReadPerm = -4,

    AddWritePerm = 2,
    RmWritePerm = -2,

    AddExecutePerm = 1,
    RmExecutePerm = -1,

    AddReadWritePerm = 6,
    RmReadWritePerm = -6,

    AddWriteExecutePerm = 3,
    RmWriteExecutePerm = -3,

    AddReadExecutePerm = 5,
    RmReadExecutePerm = -5,

    AddReadWriteExecutePerm = 7,
    RmReadWriteExecutePerm = -7
};

static char * FILE_PERM_TO_STRING[9] = {"----", NULL, "-w--", NULL,  "-r--", "-rx-", "-rw-", "-rwx", NULL};

typedef struct directory_entry {
    char * name;
    uint32_t size;
    uint16_t firstBlock;
    enum FileType type;
    enum FilePermissions perm;
    time_t mtime;
    struct directory_entry * next;
} directory_entry;

#endif


struct directory_entry * insertNewDirEntry(
    char name[], 
    uint32_t size, 
    uint16_t firstBlock, 
    enum FileType type, 
    enum FilePermissions perm, 
    time_t mtime, 
    struct directory_entry * head
);
struct directory_entry * updateDirEntry(
    char * name[], 
    uint32_t * size, 
    uint16_t * firstBlock, 
    enum FileType * type, 
    enum FilePermissions * perm, 
    time_t * mtime,
    char targetDirEntryName[],
    struct directory_entry * head
);
struct directory_entry * deleteDirEntry(char name[], struct directory_entry * head);
struct directory_entry * findDirEntry(char name[], struct directory_entry * head);
void clearList(struct directory_entry ** head);

/*
Testing Purposes
*/
void printLinkedList(struct directory_entry * head);