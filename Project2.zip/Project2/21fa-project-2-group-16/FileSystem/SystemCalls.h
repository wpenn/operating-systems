enum Mode {
    F_WRITE = 0,
    F_READ = 1,
    F_APPEND = 2
};
enum SeekFlag {
    F_SEEK_SET = 0,
    F_SEEK_CUR = 1,
    F_SEEK_END = 2
};
/**
 * 
 * FD TABLE HANDLER
 * 
 */

typedef struct fdTableEntry{
    int fd; //distinct for every mode
    char * fileName;
    enum Mode mode;
    int seekLocation;
    struct fdTableEntry * next;
} fdTableEntry;

int insertNewFD(char * fileName, enum Mode mode);

struct fdTableEntry * getFd(int fd);

struct fdTableEntry * getFdByNameMode(char * fileName, enum Mode mode);

int deleteFd(int fd);

void updateFd(
    int * fd,
    char ** fileName,
    enum Mode * mode,
    int * seekLocation,
    int fdTarget
);

void printFdTable();


/**
 * 
 * SYSTEM CALLS
 * 
 */

int f_open(char * fname, enum Mode mode);
int f_read(int fd, int n, char * buf);
int f_write(int fd, char * str, int n);
int f_close(int fd);

void f_unlink(char * fname);
void f_lseek(int fd, int offset, enum SeekFlag whence);
char * f_ls(char *filename);

void f_touch(char ** fileNames);
void f_mv(char ** argv);
void f_rm(char ** fileNames);
void f_cp(char ** argv);
void f_chmod(char ** argv);

void f_mkfs(char * filesystemName, int blocksInFat, int blockSizeConfig);
void f_mount(char * filesystemName);