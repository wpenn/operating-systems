#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <stdlib.h>
#include "parser.h"
#include "testFs.h"
#include "shell.h"

#define MAX_LINE_LENGTH 4096

/**
* Perform the main logic to run the penn-shredder shell program
*
* @param argc - the number of arguments passed in
* @param argv - the array of string arugments passed in
*/
// ORIGINAL PENN-SHELL MAIN METHOD
// int main(int argc, char *argv[]) {
// 	// check for correct arguments to penn-shredder and terminate if not 1 or 0
// 	if (argc > 2) {
// 		printf ("Illegal arguments to penn-shredder\n");
// 		exit(EXIT_FAILURE);
// 	}

// 	// Check for interactive or non-interactive mode
// 	if (isatty(STDIN_FILENO)) {
// 		// Go to interactive mode
// 		runInteractiveMode();
// 	} else {
// 		// Go to non-interactive mode
// 		runNonInteractiveMode();
// 	}

// 	exit(EXIT_SUCCESS);
// }

// Test PCB Creation main method
// int main(int argc, char *argv[]) {
// 	testPcb();
// 	exit(EXIT_SUCCESS);
// }

int main(int argc, char *argv[]) {
	runInteractiveMode();
	exit(EXIT_SUCCESS);
}