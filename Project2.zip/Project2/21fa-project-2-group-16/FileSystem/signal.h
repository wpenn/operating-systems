/** 
* Handles signals sent to the parent process
* 
* @param signum - the int id of the signal passed into the handler
*/
void signalHandler(int signum);

void childSignalHandler(int signum);