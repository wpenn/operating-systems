#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <stdlib.h>
#include "parser.h"
#include "signal.h"
#include "fsHandler.h"
#include "directoryEntryManager.h"

#define MAX_LINE_LENGTH 4096

void runInteractiveMode() {
  char cmd[MAX_LINE_LENGTH];
	int numBytes;

	// catch control C
	if (signal (SIGINT, signalHandler) == SIG_ERR) {
		fprintf(stderr, "Unable to catch SIGINT\n");
	}

  	// catch CTRL Z
	if (signal (SIGTSTP, signalHandler) == SIG_ERR) {
		fprintf(stderr, "Unable to catch SIGTSTP\n");
	}

	// catch SIGGTOU (tries to read from output)
	if (signal (SIGTTOU, SIG_IGN) == SIG_ERR) {
		fprintf(stderr, "Unable to catch SIGTTOU\n");
	}
	// catch SIGTTIN (tries to read from input)
	if (signal (SIGTTIN, signalHandler) == SIG_ERR) {
		fprintf(stderr, "Unable to catch SIGTTIN\n");
		
	}

	// start the prompt loop
	while(1) {
 		write (STDERR_FILENO, FATPROMPT, strlen(FATPROMPT));

        numBytes = read (STDIN_FILENO, cmd, MAX_LINE_LENGTH);

		// check if control D was pressed and exit if it was
		if (numBytes == -1 || numBytes == 0 || cmd[0] == '\0') {
			fprintf (stderr, "\n");
			exit(EXIT_SUCCESS);
		} 

		if (cmd[0] == '\n') {
			continue;
		}
		
		// handle the case when the user types a command then presses control D
		if (cmd[numBytes - 1] != '\n') {
			fprintf (stderr, "\n");
			cmd[numBytes] = '\n';
		}

		// add the null terminator
  		cmd[numBytes] = '\0';

		struct parsed_command *result;
		int successParsing = parse_command(cmd, &result);
		
		if (successParsing == 1) {
			// Unexpected file input
			fprintf (stderr, "Invalid: unexpected file input\n");
		} else if (successParsing == 2) {
			// parser encountered an unexpected file output token '>'
			fprintf (stderr, "Invalid: output file\n");
		} else if (successParsing == 3) {
			// parser encountered an unexpected pipeline token '|'
			fprintf(stderr, "Invalid: pipeline token\n");
		} else if (successParsing == 4) {
			// parser encountered an unexpected ampersand token '&'
			fprintf (stderr, "Invalid: ampersand token\n");
		} else if (successParsing == 5) {
			// parser didn't find input filename following '<'
			fprintf (stderr, "Invalid: No redirect input filename given.\n");
		} else if (successParsing == 6) {
			// parser didn't find output filename following '>' or '>>'
			fprintf (stderr, "Invalid: No redirect output following \'>\' or \'>>\'.\n");
		} else if (successParsing == 7) {
			// parser didn't find any commands or arguments where it expects one
			fprintf(stderr, "Invalid: No commands or arguments\n");
		} else if (!strcmp(result->commands[0][0], "mkfs")) {
            //printf("%s %d %d\n", result->commands[0][1], atoi(result->commands[0][2]), atoi(result->commands[0][3]));
			int size = 0;
            while (result->commands[0][size] != NULL) {
                size++;
            }

			if (size != 4) {
				printf("ERROR: Syntax Error.\n");
				continue;
			}

            mkfs_command(result->commands[0][1], atoi(result->commands[0][2]), atoi(result->commands[0][3]));
            free(result); //TODO: Address 70 bytes inside a block of size 77 free'd
		} else if (!strcmp(result->commands[0][0], "mount")) {
			int size = 0;
            while (result->commands[0][size] != NULL) {
                size++;
            }
			if (size != 2) {
				printf("ERROR: Syntax Error.\n");
				continue;
			}

            mountFsCommand(result->commands[0][1]);
            // free(result); 
		} else if (!strcmp(result->commands[0][0], "unmount")) {
			int size = 0;
            while (result->commands[0][size] != NULL) {
                size++;
            }

			if (size > 1) {
				printf("ERROR: Syntax Error.\n");
				continue;
			}

            unmountFsCommand();
            free(result); 
		} else if (!strcmp(result->commands[0][0], "touch")) {
			int size = 0;
            while (result->commands[0][size] != NULL) {
                size++;
            }

			if (size == 1) {
				printf("ERROR: Syntax Error.\n");
				continue;
			}

			char ** files = (char**)calloc(sizeof(char *) * size + 1, sizeof(char *));

			int index = 1;
			while (index < size) {
				files[index - 1] = result->commands[0][index]; //TODO: Need to malloc each location?
				//printf("%s\n", files[index]);
				index++;
			}

			// files[size] = NULL;

            touchCommand(files);

			free(files);
            free(result); 
		} else if (!strcmp(result->commands[0][0], "mv")) {
			int size = 0;
            while (result->commands[0][size] != NULL) {
                size++;
            }
			if (size != 3) {
				printf("ERROR: Syntax Error.\n");
				continue;
			}
			
            mvCommand(result->commands[0][1], result->commands[0][2]);
            free(result); 
		} else if (!strcmp(result->commands[0][0], "rm")) {
			int size = 0;
            while (result->commands[0][size] != NULL) {
                size++;
            }
			
			if (size == 1) {
				printf("ERROR: Syntax Error.\n");
				continue;
			}

			char ** files = (char**)calloc(sizeof(char *) * size + 1, sizeof(char *));

			int index = 1;
			while (index < size) {
				files[index - 1] = result->commands[0][index];
				//printf("%s\n", files[index]);
				index++;
			}

			//files[size] = NULL;

            rmCommand(files, DeletedEntryAndFile); //TODO: Will be changed based on kernel / scheduler

			free(files);
            free(result); 
		} else if (!strcmp(result->commands[0][0], "cat")) {
			int size = 0;
            while (result->commands[0][size] != NULL) {
                size++;
            }
			
			if (size == 1) {
				printf("ERROR: Syntax Error.\n");
				continue;
			}
			

            if (size == 3 && (strcmp(result->commands[0][1], "-w") == 0 || strcmp(result->commands[0][1], "-a") == 0)) {
				enum CommandFlag commandFlag = AppendFile;
				if (strcmp(result->commands[0][1], "-w") == 0) {
					commandFlag = OverwriteFile;
				} else if (strcmp(result->commands[0][1], "-a") == 0){
					commandFlag = AppendFile;
				} else {
					printf("INVALID FLAG INPUT");
					continue;
				}
				catCommand(NULL, result->commands[0][2], commandFlag);
            } else {
				enum CommandFlag commandFlag = AppendFile;
				int endIndex = -1;
				char * outputFile = "";

				if (result->commands[0][size - 2][0] =='-' && result->commands[0][size - 2][1] != 'w' && result->commands[0][size - 2][1] != 'a') {
					printf("INVALID FLAG INPUT");
					continue;
				} else if (strcmp(result->commands[0][size - 2], "-w") == 0) {
					commandFlag = OverwriteFile;
					endIndex = size - 2;
					outputFile = result->commands[0][size - 1];
				} else if (strcmp(result->commands[0][size - 2], "-a") == 0){
					commandFlag = AppendFile;
					endIndex = size - 2;
					outputFile = result->commands[0][size - 1];
				} else {
					//this is the case where no output is passed and so we just print to standard out
					commandFlag = PrintFile;
					endIndex = size;
					outputFile = NULL;
				}

				char ** fileNames = (char **) calloc(sizeof(char *) * endIndex + 1, sizeof(char **));
				for(int i = 1; i < endIndex; i++){
					fileNames[i - 1] = result->commands[0][i];
				}
				fileNames[endIndex] = NULL;
				printf("SIZE: %d [size + 1 = %d]\n", size, endIndex + 1);
				catCommand(fileNames, outputFile, commandFlag);
			}


            free(result); 
		} else if (!strcmp(result->commands[0][0], "cp")) {
            int size = 0;
            while (result->commands[0][size] != NULL) {
                size++;
            }
			if (size == 1) {
				printf("ERROR: Syntax Error.\n");
				continue;
			}

            int toggler = -1;
            char * source = NULL;
            char * dest = NULL;
            if (size == 3) {
                source = result->commands[0][1];
                dest = result->commands[0][2];
                toggler = 2;
            } else if (size > 3 && strcmp(result->commands[0][1], "-h") == 0) {
                source = result->commands[0][2];
                dest = result->commands[0][3];
                toggler = 0;
            } else if (size > 3 && strcmp(result->commands[0][2], "-h") == 0) {
                source = result->commands[0][1];
                dest = result->commands[0][3];
                toggler = 1;
            } else {
				printf("ERROR: Syntax Error.\n");
				continue;
			}
            cpCommand(source, dest, toggler);
            free(result); 
		} else if (!strcmp(result->commands[0][0], "ls")) {
            lsCommand();
            free(result);
		} else if (!strcmp(result->commands[0][0], "chmod")) {
            int size = 0;
            while (result->commands[0][size] != NULL) {
                size++;
            }
			if (size != 3) {
				printf("Invalid number of commands");
				continue;
			}

			char * fileName = result->commands[0][2];

			char * permission = result->commands[0][1];

			enum PermissionChangeAction change = AddReadPerm;

			if (!strcmp(permission, "+r")) {
				change = AddReadPerm;
			} else if (!strcmp(permission, "-r")) {
				change = RmReadPerm;
			} else if (!strcmp(permission, "+w")) {
				change = AddWritePerm;
			} else if (!strcmp(permission, "-w")) {
				change = RmWritePerm;
			} else if (!strcmp(permission, "+x")) {
				change = AddExecutePerm;
			} else if (!strcmp(permission, "-x")) {
				change = RmExecutePerm;
			} else if (!strcmp(permission, "+rw")) {
				change = AddReadWritePerm;
			} else if (!strcmp(permission, "-rw")) {
				change = RmReadWritePerm;
			} else if (!strcmp(permission, "+wx")) {
				change = AddWriteExecutePerm;
			} else if (!strcmp(permission, "-wx")) {
				change = RmWriteExecutePerm;
			} else if (!strcmp(permission, "+rx")) {
				change = AddReadExecutePerm;
			} else if (!strcmp(permission, "-rx")) {
				change = RmReadExecutePerm;
			} else if (!strcmp(permission, "+rwx")) {
				change = AddReadWriteExecutePerm;
			} else if (!strcmp(permission, "-rwx")) {
				change = RmReadWriteExecutePerm;
			} else {
				printf("Invalid permission input");
				continue;
			}

			chmodCommand(fileName, change);

            free(result); 
		} else {
			printf("ERROR: Syntax Error.\n");
		}
	}
}