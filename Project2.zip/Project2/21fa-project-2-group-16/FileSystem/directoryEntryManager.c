#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "directoryEntryManager.h"

struct directory_entry * insertNewDirEntry(
    char name[], 
    uint32_t size, 
    uint16_t firstBlock, 
    enum FileType type, 
    enum FilePermissions perm, 
    time_t mtime, 
    struct directory_entry * head
){
    struct directory_entry * newEntry = (struct directory_entry * ) malloc (sizeof(struct directory_entry));
    char * newName = (char * ) malloc(32);
    strcpy(newName, name);
    newEntry->name = newName;

    newEntry->size = size;
    newEntry->firstBlock = firstBlock;
    newEntry->type = type;
    newEntry->perm = perm;
    newEntry->mtime = mtime;
    newEntry->next = NULL;
    
    if (head == NULL){
        head = newEntry;
        return head;
    }

    struct directory_entry * ptr = head;
    while(ptr->next != NULL){
        ptr = ptr->next;
    }
    ptr->next = newEntry;

    return head;
}

struct directory_entry * updateDirEntry(
    char * name[], 
    uint32_t * size, 
    uint16_t * firstBlock, 
    enum FileType * type, 
    enum FilePermissions * perm, 
    time_t * mtime,
    char targetDirEntryName[],
    struct directory_entry * head
){
    struct directory_entry * targetFile = findDirEntry(targetDirEntryName, head);
    if (name != NULL){
        free(targetFile->name);
        targetFile->name = (char *) malloc(32);
        strcpy(targetFile->name, *name);
    }
    if (size != NULL){
        targetFile->size = *size;
    }
    if (firstBlock != NULL){
        targetFile->firstBlock = *firstBlock;
    }
    if (type != NULL){
        targetFile->type = *type;
    }
    if (perm != NULL){
        targetFile->perm = *perm;
    }
    if (mtime != NULL){
        targetFile->mtime = *mtime;
    }
    return head;
}

struct directory_entry * deleteDirEntry(char name[], struct directory_entry * head){
    struct directory_entry * curFile = head;
    struct directory_entry * prevFile = NULL;

    if (head == NULL){
        return NULL;
    }

    while (strcmp(curFile->name, name) != 0){
        if (curFile->next == NULL){
            return head;
        }
        prevFile = curFile;
        curFile = curFile->next;
    }

    if (curFile == head){
        head = head->next;
    } else {
        prevFile->next = curFile->next;
    }
    free(curFile->name);
    free(curFile); //TODO: check if correct
    
    return head;
}

struct directory_entry * findDirEntry(char name[], struct directory_entry * head){
    struct directory_entry * curFile = head;
    if (head == NULL){
        return NULL;
    }
    while (strcmp(curFile->name, name) != 0){
        if(curFile->next == NULL){
            return NULL;
        }
        curFile = curFile->next;
    }

    return curFile;
}

void clearList(struct directory_entry ** head){
    struct directory_entry * curFile = *head;
    while (curFile != NULL){
        struct directory_entry * nextFile = curFile->next;
        free(curFile->name);
        free(curFile);
        curFile = nextFile;
    }
    *head = NULL;
}

void printLinkedList(struct directory_entry * head){
    struct directory_entry * curNode = head;
    int count = 0;
    printf("\n\n----------------\n");
    while (curNode != NULL){
        printf(" Node %d -  File %s || Size %d || FirstBlock %d || Type %d || Perm %d || mtime %ld \n", count, curNode->name, curNode->size, curNode->firstBlock, curNode->type, curNode->perm, curNode->mtime);
        count++;
        curNode = curNode->next;
    }
    printf("----------------\n\n");
}