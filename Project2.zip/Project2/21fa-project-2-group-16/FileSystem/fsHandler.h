#include <stdlib.h>
#include <stdint.h>
#include "directoryEntryManager.h"

struct directory_entry * getHead();

//making the file system
void mkfs_command(char * fsName, int blocksInFAT, int blockSizeConfig);

//mounting the file system
// void setGlobalsSizing(u_int16_t blockSizeConfig, u_int16_t blocksInFat);
void mountFsCommand(char * fsName);
// struct directory_entry * populateDataStructures(uint16_t *fat);

//unmounting the file system
void unmountFsCommand();

//Touch Command (creating file)
void touchCommand(char ** files);

//MV Command
void mvCommand(char * source, char * dest);

//RM Command
void rmCommand(char ** fileNames, enum FileNameMarker specialMarker);

void lsCommand();
char * lsCommandAllFiles();
char * lsCommandOneFile(char * fileName);

void cpCommand(char * source, char * dest, int toggler);

void chmodCommand(char * fileName, enum PermissionChangeAction change);

enum CommandFlag {
  OverwriteFile, // -a flag
  AppendFile, // -w flag
  PrintFile //no flag
};

void catCommand(char ** fileNames, char * outputFile, enum CommandFlag commandFlag);


//Helpers

int findFirstOpenDataBlockNumber();

int findOpenMetaDataLocation();

void writeMetaData(int fs_fd, char * fileName, uint32_t size, uint16_t firstBlock, enum FileType type, enum FilePermissions perm, time_t curTime);
void writeMetaDataFileExists(int fs_fd, char * fileName, uint32_t size, uint16_t firstBlock, enum FileType type, enum FilePermissions perm, time_t curTime);

int getLengthOfFile(char * fileName);
int getAllFileData(char * buf, char * fileName, int offset, int bytes);
int writeToFileData(char * str, char * fileName, int offset, int bytes);