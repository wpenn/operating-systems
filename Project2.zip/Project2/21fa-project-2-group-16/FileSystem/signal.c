#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <stdlib.h>

extern int currChildPid;

/** 
* Handles signals sent to the parent process
* 
* @param signum - the int id of the signal passed into the handler
*/
void signalHandler(int signum) {
	if (signum == SIGINT) {
		// catch control c
		printf ("\n");
		write (STDERR_FILENO, FATPROMPT, strlen(FATPROMPT));
	} else if (signum == SIGTSTP) {
		// fprintf (stderr, "handling sig stop\n");
	} else if (signum == SIGTTIN) {
		fprintf (stderr, "handling sigttin\n");
		
		
	} else if (signum == SIGTTOU) {
		fprintf (stderr, "handling sigttou\n");
	} else if (signum == SIGQUIT) {
		fprintf (stderr, "handling sigquit\n");
	}
}

void childSignalHandler(int signum) {
	// if (signum == SIGTSTP) {
		// Get current process that's running and stop it
		// fprintf(stderr, "\nStopped: <the command> %d\n", 0);
	// }
}