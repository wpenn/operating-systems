// #include <stdio.h>
// #include <unistd.h>
// #include "fsHandler.h"
// #include "directoryEntryManager.h"

// void testMkfs(char * name, int numBlocks, int blockSize){
//     mkfs_command(name, numBlocks, blockSize);
// }

// void testMount(){
//     // u_int16_t * fat = mountFsCommand(name); //<= also pass in a pointer to our linked list here!!!
//     // struct directory_entry * entryList = populateDataStructures(fat);
//     // entryList = NULL;
//     mountFsCommand("testFS");
//     unmountFsCommand();
// }

// void testCP(){
//     char * fsName = "minfs";
//     int numBlocks = 1;
//     int blockSize = 1;

//     mkfs_command(fsName, numBlocks, blockSize);
//     mountFsCommand(fsName);
//     cpCommand("demo2", "f1", 0);
//     cpCommand("f1", "demo3", 1);
//     cpCommand("f1", "f2", 2);
//     unmountFsCommand();
// }

// void testUnMount(char * name){
//     mountFsCommand(name); //<= also pass in a pointer to our linked list here!!!

//     struct directory_entry * entryList = NULL; //populateDataStructures(fat);

//     char name1[32] = "testFile1\0";
//     char * name1Ptr = name1;
//     entryList = insertNewDirEntry(name1Ptr, 1, 1, 1, 1, 1, entryList);
//     printLinkedList(entryList);

//     char * name2 = "testFile2";
//     entryList = insertNewDirEntry(name2, 2, 2, 2, 2, 2, entryList);
//     printLinkedList(entryList);

//     char * name3 = "testFile3";
//     entryList = insertNewDirEntry(name3, 3, 3, 3, 3, 3, entryList);
//     printLinkedList(entryList);
    
//     unmountFsCommand(entryList);
// }

// void testDEM(){ //entry manager
//     char name1[32] = "testFile1\0";
//     char * name1Ptr = name1;
//     struct directory_entry * head = NULL;
//     head = insertNewDirEntry(name1Ptr, 1, 1, 1, 1, 1, head);
//     printLinkedList(head);

//     char * name2 = "testFile2";
//     head = insertNewDirEntry(name2, 2, 2, 2, 2, 2, head);
//     printLinkedList(head);

//     char * name3 = "testFile3";
//     head = insertNewDirEntry(name3, 3, 3, 3, 3, 3, head);
//     printLinkedList(head);

//     head = deleteDirEntry("testFile2", head);
//     printLinkedList(head);

//     char newName[32] = "testFileOne";
//     char * newNamePtr = newName;
//     head = updateDirEntry(&newNamePtr, NULL, NULL, NULL, NULL, NULL, "testFile1", head);
//     printLinkedList(head);

//     struct directory_entry * file = findDirEntry("testFileOne", head);
//     printf("Found File: %s !\n", file->name);

//     // head = deleteDirEntry("testFile3", head);
//     // printLinkedList(head);

//     // head = deleteDirEntry("testFileOne", head);
//     // printLinkedList(head);
//     clearList(&head);
//     printLinkedList(head);
// }

// void testTouchCommand(){
//     char * fsName = "testFS";
//     int numBlocks = 4;
//     int blockSize = 0;

//     mkfs_command(fsName, numBlocks, blockSize);
//     mountFsCommand(fsName);
//     char * myStrings[] = { "f1", "f2", "f3", "f4", "f5", NULL};
//     char ** myStringsPtr = myStrings;
//     touchCommand(myStringsPtr);
    
//     sleep(1);

//     char * myStrings2[] = {"f1", NULL}; //update values
//     myStringsPtr = myStrings2;
//     touchCommand(myStrings2);

//     mvCommand("f2", "fileNewName2"); //Normal
//     mvCommand("fileNewName2", "fNewShit"); //Shorter Name

//     mvCommand("f5", "fspillOver"); //File in another directory block
//     mvCommand("f100", "hello world"); //Non-existant file
    
//     char * myStrings3[] = {"f7", "F8", "f9", "f10", NULL}; //double overflow
//     myStringsPtr = myStrings3;
//     touchCommand(myStringsPtr);
//     mvCommand("f3", "f");
    
//     unmountFsCommand();
// }   

// void testRm(){
//     char * fsName = "testFS";
//     int numBlocks = 4;
//     int blockSize = 0;

//     mkfs_command(fsName, numBlocks, blockSize);
//     mountFsCommand(fsName);
//     char * myStrings[] = { "f1", "f2", "f3", "f4", "f5", NULL};
//     char ** myStringsPtr = myStrings;
//     touchCommand(myStringsPtr);

//     char * rmStrings[] = {"f1", "f5", NULL};
//     myStringsPtr = rmStrings; 
//     rmCommand(myStringsPtr);

//     char * myStrings3[] = { "fNew1", "fNew2", "fNew3", NULL};
//     myStringsPtr = myStrings3;
//     touchCommand(myStringsPtr);


//     unmountFsCommand();
// }

// void testLs(){
//     char * fsName = "testFS";
//     int numBlocks = 1;
//     int blockSize = 1;

//     mkfs_command(fsName, numBlocks, blockSize);
//     mountFsCommand(fsName);
//     char * myStrings[] = { "f1", "f2", "f3", "f4", "f5", NULL};
//     char ** myStringsPtr = myStrings;
//     touchCommand(myStringsPtr);

//     lsCommand();

//     unmountFsCommand();
// }

// void testChmod(){
//     char * fsName = "testFS";
//     int numBlocks = 4;
//     int blockSize = 0;

//     mkfs_command(fsName, numBlocks, blockSize);
//     mountFsCommand(fsName);
//     char * myStrings[] = { "f1", "f2", "f3", "f4", "f5", NULL};
//     char ** myStringsPtr = myStrings;
//     touchCommand(myStringsPtr);

//     chmodCommand("f3", AddExecutePerm); //Base Add
//     chmodCommand("f5", RmReadPerm); //Base Rm
//     chmodCommand("f5", AddExecutePerm); //Fail Case
//     chmodCommand("f1", RmReadWriteExecutePerm); // Remove All
//     chmodCommand("f2", AddReadWritePerm); //No change

//     lsCommand();

//     unmountFsCommand();
// }

// void testCat(){
//     char * fsName = "testFS";
//     int numBlocks = 4;
//     int blockSize = 0;

//     mkfs_command(fsName, numBlocks, blockSize);
//     mountFsCommand(fsName);
//     char * myStrings[] = { "f1", "f2", "f3", "f4", NULL};
//     char ** myStringsPtr = myStrings;
//     touchCommand(myStringsPtr);

//     catCommand(NULL, "f1", AppendFile);
//     catCommand(NULL, "nonExistantFile", AppendFile);
//     catCommand(NULL, "f1", AppendFile);

//     char * myStrings2[] = { "overflowFile1", NULL};
//     myStringsPtr = myStrings2;
//     touchCommand(myStringsPtr);

//     catCommand(NULL, "overflowFile1", AppendFile);

//     unmountFsCommand();
// }

// void testDemo(){
//     mkfs_command("minfs", 1, 1); //mkfs minfs 1 1
//     mkfs_command("maxfs", 32, 4); //mkfs maxfs 32 4

//     mountFsCommand("maxfs"); // mount minfs
//     cpCommand("demo2", "f1", 0); //cp -h demo2 f1
//     unmountFsCommand();

//     mountFsCommand("minfs"); //mount minfs
//     catCommand(NULL, "f1", AppendFile); //cat -a f1
//     unmountFsCommand();

//     mountFsCommand("minfs"); 
//     char * myStrings[] = { "f1", NULL};
//     char ** myStringsPtr = myStrings;
//     rmCommand(myStringsPtr); //rm f1
//     unmountFsCommand();

//     mountFsCommand("minfs");
//     cpCommand("demo3", "f2", 0); //cp -h demo3 f2
//     unmountFsCommand();
// }

// void testFs(){
//     printf("\n============================\nSTARTING PENNFAT SHELL\n============================\n\n");
    
//     //testTouchCommand();
//     //testMount();

//     // testRm();

//     // testLs();
//     // testCat();
//     // testCP();
//     // testChmod();

//     // testDemo();
//     printf("============================\nENDING PENNFAT SHELL\n============================\n\n");
// }