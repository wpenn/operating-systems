#include <stdio.h>

FILE *fp;

FILE* getFile();

void logCreate(int ticks, int pid, int priorityLevel, char** cmd);

void logSignaled(int ticks, int pid, int priorityLevel, char** cmd);

void logStopped(int ticks, int pid, int priorityLevel, char** cmd);

void logContinued(int ticks, int pid, int priorityLevel, char** cmd);

void logSchedule(int ticks, int pid, int priorityLevel, char** cmd);

void logNice(int ticks, int pid, char** cmd);

void logUnblocked(int ticks, int pid, int priorityLevel, char** cmd);

void logBlocked(int ticks, int pid, int priorityLevel, char** cmd);