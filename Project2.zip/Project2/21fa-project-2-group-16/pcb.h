#include <stdlib.h>
#include <ucontext.h>
#include <stdbool.h>

#ifndef PCB
#define PCB
    
typedef struct pcb_struct {
    ucontext_t *ucontext;
    int priorityLevel; // priority level in the 
    int pid; 
    int fdIn; // stdin of this process
    int fdOut; // stdout of this process
    int numTicks; // number of ticks for this process if sleep
    int startingTick; // starting tick for this process if sleep
    int parentPID; // the pid of the parent process
    int childPids[100]; // list of childPids from this process
    char** command; // the command name (used for logging)
    bool statusChanged; // flag to indicate if this process should be waited on
    enum status {READY, RUNNING, BLOCKED, STOPPED, ZOMBIED, ORPHANED} status;
    // zombie queue here -- to kill all the children later on if this exits
} pcb;

pcb* createPcb(int pid, int parentPID, int fdIn, int fdOut, ucontext_t *ucontext, int pL, char** cmd);

void printPcb(pcb* pcb);

void printCommand(pcb* p);

char* get_status(int status);

#endif

