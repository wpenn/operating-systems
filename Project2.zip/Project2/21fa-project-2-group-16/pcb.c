#include <stdio.h>
#include <stdbool.h>
#include "pcb.h"

/*
Creates pcb given a pid
*/
pcb* createPcb(int pid, int parentPID, int fdIn, int fdOut, ucontext_t *ucontext, int pL, char** cmd) {
    pcb* pcb = malloc(sizeof(*pcb));
        
    // malloc ucontext outside of this function
    pcb->ucontext = ucontext;
    pcb->pid = pid;
    pcb->parentPID = parentPID;
    pcb->fdIn = fdIn;
    pcb->fdOut = fdOut;
    pcb->priorityLevel = pL;
    pcb->command = cmd;
    pcb->statusChanged = false;
    pcb->numTicks = 0;
    pcb->startingTick = 0;

    for (int i = 0; i < 100; i++) {
        pcb->childPids[i] = 0;
    }
    pcb->status = READY;

    // how much time has run already
    return pcb;
}

/*
Free a pcb
*/
void freePcb(pcb* pcb) {
    // TODO: free ucontext stack ?
    // free (pcb->ucontext->uc_stack);
    free(pcb);
}

/*
Prints contents of pcb
*/
void printPcb(pcb* pcb) {
    if (pcb == NULL) {
        fprintf(stderr, "Printing pcb, but pcb is null\n"); 
    } else {
        char* status = get_status(pcb->status);
        fprintf(stderr, "%d\t%d\t%d\t%s\t", pcb->pid, pcb->parentPID, pcb->priorityLevel, status);
        
        int currWordIdx = 0;
        while (pcb->command[currWordIdx] != NULL) {
            fprintf (stderr, "%s ", pcb->command[currWordIdx]);
            currWordIdx++; 
        }
        
        fprintf(stderr, "\n");
        
    }
}

void printCommand(pcb* p) {
    int currWordIdx = 0;
    while (p->command[currWordIdx] != NULL) {
        fprintf (stderr, "%s ", p->command[currWordIdx]);
        currWordIdx++; 
    }
    
    fprintf(stderr, "\n");
}

char* get_status(int status) {
    if (status == 0) {
        // Ready
        return "R";
    } else if (status == 1) {
        // Running (we didn't implement this but we should ?)
        return "R";
    } else if (status == 2) {
        return "B";
    } else if (status == 3) {
        return "S";
    } else if (status == 4) {
        return "Z";
    } else {
        return "O";
    }
}