#include "node.h"
#include "queue.h"

// void s_sleep(char *t);
void busy();
void ps();
void s_kill(char*** commands);
void zombie_child();
void zombify();
void orphan_child();
void orphanify();
void s_sigterm(int pid);
void s_sigstop();
void s_sigcont();
void setupShellQueue();
int spawnProcessForNice (char*** commands, int fdIn, int fdOut, int priorityLevel);

// FS Commands
void s_touchCommand(char ** fileNames);
void s_lsCommand(char ** argv);
void s_mvCommand(char ** argv);
void s_rmCommand(char ** fileNames);
void s_catCommand(char ** argv);
void s_cpCommand(char ** argv);
void s_chmodCommand(char ** argv);


void s_echo(char** words);
void s_sleep(char** arg);
void s_fg(node *job, shellQueue *q, bool fromBackground);
void s_bg(node *job, shellQueue *q);
void man();