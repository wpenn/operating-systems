#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/time.h>  
#include <stdlib.h>
#include <signal.h>
#include "queueOs.h"
#include "pcb.h"
#include "signal.h"
#include "userFuncs.h"
#include "logFuncs.h"
#include "scheduler.h"

#define HIGH -1
#define MIDDLE 0
#define LOW 1


/*
Called at the beginning of main to malloc the queues
*/
void setupQueues() {
    highestPQ = malloc(sizeof(queue));
    highestPQ->size = 0;
    highestPQ->head = NULL;

    middlePQ = malloc(sizeof(queue));
    middlePQ->size = 0;
    middlePQ->head = NULL;

    lowestPQ = malloc(sizeof(queue));
    lowestPQ->size = 0;
    lowestPQ->head = NULL;

    completedQ = malloc(sizeof(queue));
    completedQ->size = 0;
    completedQ->head = NULL;

    currentRunningPcb = NULL;
    foregroundProcess = NULL;
}

queue* getStoppedQ() {
    return stoppedQ;
}

queue* getHPQ() {
    return highestPQ;
}

queue* getMPQ() {
    return middlePQ;
}

queue* getLPQ() {
    return lowestPQ;
}

void setForegroundProcess(pcb* f) {
    foregroundProcess = f;
}

/*
Set up contexts for main
*/
void setupContexts() {
    schedulerFuncContext = malloc(sizeof(ucontext_t));

    // Must makecontext for idleProcess
    idleProcessContext = malloc(sizeof(ucontext_t));
    getcontext(idleProcessContext);

    void *sp = NULL;
    fillUContextStack(idleProcessContext, sp);

    idleProcessContext->uc_link = schedulerFuncContext;
    // idleProcessContext->uc_link = NULL;
    makecontext(idleProcessContext, idleProcess, 0);
}

/*
Process scheduler
*/
void schedule() {
    getcontext(schedulerFuncContext);
    // idleProcessContext->uc_link = schedulerFuncContext;

    // TODO: check if we've signed to terminate program
    // will be a flag that we set in shell
    while (1) {
        pcb* processToRun = nextProcessToRun();
         
        if (processToRun == NULL) {
            // right now idle is scheduled between spawning and running a process for some reason
            // do we need to block timeout? and if so, why is our signal blocking broken?
            currentRunningPcb = idleProcessPcb;

            
            logSchedule(total_ticks, idleProcessPcb->pid, idleProcessPcb->priorityLevel, idleProcessPcb->command);
            swapcontext(schedulerFuncContext, idleProcessContext);

        } else {
            currentRunningPcb = processToRun;
            logSchedule(total_ticks, processToRun->pid, processToRun->priorityLevel, processToRun->command);
            
            swapcontext(schedulerFuncContext, currentRunningPcb->ucontext);
        }    
        
    }
}

/*
Chooses the next process to run, called in schedule()
*/
pcb* nextProcessToRun() {
    int highestIsEmpty = isEmpty(highestPQ);
    int middleIsEmpty = isEmpty(middlePQ);
    int lowestIsEmpty = isEmpty(lowestPQ);
    
    pcb *processToRun = NULL;

    if (!highestIsEmpty && !middleIsEmpty && !lowestIsEmpty) {
        // all three of the queues are nonempty
        int r = rand() % 19;

        if (r < 4) {
            // schedule lowest priority
            processToRun = popFirstReadyProcess(lowestPQ);
        }
        
        if (processToRun == NULL || r < 10) {
            // schedule middle priority
            processToRun = popFirstReadyProcess(middlePQ);
        }

        
        if (processToRun == NULL) {
            processToRun = popFirstReadyProcess(highestPQ);
        }
    } else if (!highestIsEmpty && !middleIsEmpty) {
        // only the highest and middle have things in their queues
        int r = rand() % 10;

        if (r < 4) {
            // schedule middle priority
            processToRun = popFirstReadyProcess(middlePQ);
        }

        if (processToRun == NULL) {
            // schedule high priority
            processToRun = popFirstReadyProcess(highestPQ);
        }
    } else if (!middleIsEmpty && !lowestIsEmpty) {
        // only the middle and lowest have things in their queues
        int r = rand() % 10;

        if (r < 4) {
            // schedule low priority
            processToRun = popFirstReadyProcess(lowestPQ);
        }
        
        if (processToRun == NULL) {
            // schedule middle priority
            processToRun = popFirstReadyProcess(middlePQ);
        }
    } else if (!highestIsEmpty && !lowestIsEmpty) {
        // only the highest and lowest have things in the queue
        int r = rand() % 13;

        if (r < 4) {
            // schedule low priority
            processToRun = popFirstReadyProcess(lowestPQ);
        }
        
        if (processToRun == NULL) {
            // schedule high priority
            processToRun = popFirstReadyProcess(highestPQ);
        }
    } else if (!highestIsEmpty) {
        // only the highest has things in the queue, so regular round robin
        processToRun = popFirstReadyProcess(highestPQ);
    } else if (!middleIsEmpty) {
        // only the middle has things in the queue, so regular RR
        processToRun = popFirstReadyProcess(middlePQ);
    } else if (!lowestIsEmpty) {
        // only the lowest has things in the queue, so regular RR
        processToRun = popFirstReadyProcess(lowestPQ);
    }

    return processToRun;
}

void printAllQueues() {
    fprintf(stderr, "Printing highestPQ\n");
    printQueue(highestPQ, PCB_TYPE);
    fprintf(stderr, "\nPrinting middlePQ\n");
    printQueue(middlePQ, PCB_TYPE);
    fprintf(stderr, "\nPrinting lowestPQ\n");
    printQueue(lowestPQ, PCB_TYPE);
}

void printForPs() {
    printQueue(highestPQ, PCB_TYPE);
    printQueue(middlePQ, PCB_TYPE);
    printQueue(lowestPQ, PCB_TYPE);
}

/*
Adds the new process to the correct priority queue
Called from k_process_create
*/
void addProcessToQueue (pcb* pcb, int priorityLevel) {
    element* node = makeElement(pcb);
    
    if (priorityLevel == HIGH) {
        pushToBack(highestPQ, node);
    } else if (priorityLevel == MIDDLE) {
        pushToBack(middlePQ, node);
    } else {
        pushToBack(lowestPQ, node);
    }
}


/*
Called when a process finishes
From p_exit()
*/
void processCompleted() {
    // fprintf (stderr, "process completed pid %d\n", currentRunningPcb->pid);
    element *e = makeElement(currentRunningPcb);
    currentRunningPcb->status = ZOMBIED;
    changeProcessState(currentRunningPcb->pid, currentRunningPcb, ZOMBIED);
    
    pushToBack(completedQ, e);
    // is the foreground process always set back to the shell ?
    foregroundProcess = getPcb(1);
    setcontext(schedulerFuncContext); // ONLY TIME WE SHOULD SETCONTEXT
}

void changeProcessState(int pid, pcb* p, int newState) {
    // fprintf (stderr, "process pid %d changed state %d\n", p->pid, newState);
    p->status = newState;
    p->statusChanged = true;
    element* parentElt = findElementInQueues(p->parentPID);
    // printAllQueues();
    // fprintf (stderr, "in changeProcessState: parent Elt is null: %d\n", parentElt == NULL);

    if (parentElt != NULL) {
        pcb* parent = (pcb*) parentElt->value;
        // fprintf (stderr, "in changeProcessState: setting parent pid %d process to ready\n", parent->pid);
        if (parent->status == BLOCKED) {
            changeProcessState(parent->pid, parent, READY);
        }
        // TODO: is there a case where the parent would be stopped/not running
        // other than blocked bc its waiting for the child ?
    }

    // TODO: do we need to check if the parent is in the completed queue ??
}

pcb* findCompletedProcess(int pid) {
    // find the element out of the completed q w given pid
    element *e = findPcbElement(completedQ, pid);
    if (e == NULL) {
        return NULL;
    }

    pcb *p = e->value;
    return p;
}

/* 
finds the queue pcb is in 
removes pcb from queue
*/
void findAndRemovePcb(pcb* process) {
  if (process->priorityLevel == -1) {
    popWithPid(highestPQ, process->pid);
  } else if (process->priorityLevel == 0) {
    popWithPid(middlePQ, process->pid);
  } else {
    popWithPid(lowestPQ, process->pid);
  }
}

/*
finds and adds element back into its original queue 
(taken out bc stopped/blocked..etc.)
*/
void findAddBackElem(element *e) {
  int pLevel = ((pcb*) e->value)->priorityLevel;
  if (pLevel == -1) {
    pushToBack(highestPQ, e);
  } else if (pLevel == 0) {
    pushToBack(middlePQ, e);
  } else {
    pushToBack(lowestPQ, e);
  }
}

/*
Push to completedQ
Called from in kernelFuncs.c from k_process_cleanup
*/
void pushToCompletedQ(pcb* pcb) {
    element *e = findElementInQueues(pcb->pid);
    pushToBack(completedQ, e);
    // fprintf(stderr, "after push to completed\n");
}

// looks through all the ready queues to find a process w certain pid
element* findElementInQueues(int pid) {
    element* e = NULL;
    if (!isEmpty(middlePQ)) {
        e = findPcbElement(middlePQ, pid);
    }

    if (e == NULL && !isEmpty(highestPQ)) {
        e = findPcbElement(highestPQ, pid);
    }

    if (e == NULL && !isEmpty(lowestPQ)) {
        e = findPcbElement(lowestPQ, pid);
    }
    
    return e;
}

/**
This function is called if the process times out
*/
void alarmHandler() {
    total_ticks++;

    // If the currentRunningPcb is not the idle process
    if (currentRunningPcb->pid != idleProcessPcb->pid) {
        // add the current running PCB back onto its priority queue
        element *e = makeElement(currentRunningPcb);

        int priorityLevel = currentRunningPcb->priorityLevel;
        
        // put the current running process back into its correct ready queue
        if (priorityLevel == HIGH) {
            pushToBack(highestPQ, e);
        } else if (priorityLevel == MIDDLE) {
            pushToBack(middlePQ, e);
        } else {
            pushToBack(lowestPQ, e);
        }
    }

    // iterate over the queue and see what elements are sleep and check if any of them are done
    checkForCompletedSleepProcesses(highestPQ);
    checkForCompletedSleepProcesses(middlePQ);
    checkForCompletedSleepProcesses(lowestPQ);
    
    // fprintf(stderr, "currentRunningPcb pid is %d\n", currentRunningPcb->pid);
    if (currentRunningPcb->pid != idleProcessPcb->pid) {
        swapcontext(currentRunningPcb->ucontext, schedulerFuncContext);
    } else {
        setcontext(schedulerFuncContext);
    }
    // swaps the context back to the scheduler from the current running process
    
}

// checks for any sleep processes that have reached their end on this time tick
void checkForCompletedSleepProcesses(queue *q) {
    element *tmp = q->head;
    while (tmp != NULL) {
        pcb* curr = ((pcb*) tmp->value);

        // if the sleep is blocked -> set it to ready now. This will allow it to call p_exit
        if (curr->status == BLOCKED && !strcmp(curr->command[0], "sleep")) {
            
            if (total_ticks >= curr->startingTick + curr->numTicks) {
                // fprintf(stderr, "total_ticks: %d\n", total_ticks);
                curr->status = READY;
            }
        }

        tmp = tmp->next;
    }
}


/* returns the total number of clock ticks since the start of the program */
int getTicks() {
    return total_ticks;
}

/* registers the alarm handler in main
should only be called once when the program starts
*/
static void setAlarmHandler(void) {
	struct sigaction act;

	act.sa_handler = alarmHandler; 
	act.sa_flags = SA_RESTART; //unsure if needed
	sigfillset(&act.sa_mask);
    sigaction(SIGALRM, &act, NULL);
}

/*
 sets a timer for the interval of a clock tick
 should only be called once when the program starts
*/
static void setTimer(void){
    struct itimerval it;

    // set the timer to 100 milliseconds
    it.it_interval = (struct timeval) { .tv_usec = millisecond * 100 };
    it.it_value = it.it_interval;
    setitimer(ITIMER_REAL, &it, NULL);
}

// combined function to set up the timer and alarm handler for clock ticks
void clock_ticks() {
	setTimer();
	setAlarmHandler();
}

/*
Gets PCB with pid
Mainly for signal handling
*/
pcb* getPcb (int pid) {
    
    pcb* p = NULL;
    element* e = NULL;
    if (findPcbElement(highestPQ, pid) != NULL) {
        e = findPcbElement(highestPQ, pid);        
    } else if (findPcbElement(middlePQ, pid) != NULL) {
        e = findPcbElement(middlePQ, pid);
    } else {
        e = findPcbElement(lowestPQ, pid);
    }

    // If we could not find the element
    if (e == NULL) {
        return NULL;
    }
    p = (pcb*) e->value;
    return p;

}

/*
Removes the element from the queue
Must free
*/
void removePcb(int pid) {
    if (findPcbElement(highestPQ, pid) != NULL) {
        popWithPid(highestPQ, pid);
        // fprintf(stderr, "Printing highestPQ\n");
        // printQueue(highestPQ, PCB_TYPE);
    } else if (findPcbElement(middlePQ, pid) != NULL) {
        popWithPid(middlePQ, pid);
        // fprintf(stderr, "\nPrinting middlePQ\n");
        // printQueue(middlePQ, PCB_TYPE);
    } else if (findPcbElement(lowestPQ, pid) != NULL) {
        popWithPid(lowestPQ, pid);
        // fprintf(stderr, "\nPrinting lowestPQ\n");
        // printQueue(lowestPQ, PCB_TYPE);
    } else {
        fprintf(stderr, "NOT IN ANY QUEUES ?????\n");
    }
}

// function to move the priority of a process (called by p_nice)
void k_nice(int pid, int priority) {
    element* e = findPcbElement(highestPQ, pid);
    
    if (e != NULL) {
        if (priority != HIGH) {
            // move to the corrent PQ
            pcb * popped = popWithPid(highestPQ, pid);
            if (priority == MIDDLE){
                logNice(getTicks(), pid, popped->command);
            } else {
                logNice(getTicks(), pid, popped->command);
                pushToBack(lowestPQ, e);
            }
            
        } 
        return;
    } 

    e = findPcbElement(middlePQ, pid);
    if (e != NULL) {
       
        if (priority != MIDDLE) {
            pcb* popped = popWithPid(middlePQ, pid);
            // move to priority PQ
            if (priority == HIGH){
                logNice(getTicks(), pid, popped->command);
                pushToBack(highestPQ, e);
            } else {
                logNice(getTicks(), pid, popped->command);
                pushToBack(lowestPQ, e);
            }
        }
        return;
    } 

    e = findPcbElement(lowestPQ, pid);
    if (e != NULL) {
        if (priority != LOW) {
            // move to priorty Q
            pcb* popped = popWithPid(lowestPQ, pid);
            if (priority == HIGH){
                logNice(getTicks(), pid, popped->command);
                pushToBack(highestPQ, e);
            } else {
                logNice(getTicks(), pid, popped->command);
                pushToBack(middlePQ, e);
            }
        }
        return;
    }
}
