#include <stdlib.h>
#include <stdio.h>
#include "pcb.h"

#define PCB_TYPE 0

#ifndef QUEUE
#define QUEUE



typedef struct queue_struct {
  int size;
  struct element_struct *head;
} queue; // change this back

#endif

#ifndef ELEMENT
#define ELEMENT 

typedef struct element_struct {
  void* value;
  struct element_struct *next;
} element;

element* makeElement(void *node);

int isEmpty(queue* q);

element* popFromFront(queue* q);

void pushToBack(queue* q, element *e);

void printQueue(queue* q, int type);

element* findPcbElement(queue* q, int pid);

pcb* popFirstReadyProcess(queue *q);

pcb* popWithPid(queue* q, int pid);

void findAddBackElem(element *e);


#endif
