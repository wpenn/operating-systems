void handleRedirects (int childNumber, int totalChildren, const char *stdin_file, const char *stdout_file, int is_file_append);
