#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <fcntl.h>
#include "shell_funcs.h"
#include "userFuncs.h"
#include "signal.h"
#include "node.h"
#include "queue.h"
#include "scheduler.h"
#include "parser.h"
#include "FileSystem/SystemCalls.h"


void busy() {
	// just call idle process?
}

void ps() {
	fprintf(stderr, "PID    PPID    PRI    STAT\t CMD\n");
	char* status = get_status(currentRunningPcb->status);
	fprintf(stderr, "%d\t%d\t%d\t%s\t", currentRunningPcb->pid, currentRunningPcb->parentPID, currentRunningPcb->priorityLevel, status);
  	printCommand(currentRunningPcb);
	printForPs();

  	p_exit();
}

void s_kill(char*** commands) {
	int def = 1; // assume default
      char *killArg = commands[0][1];
      for (int i = 0; i < strlen(killArg); i++) {
        if (!isdigit(killArg[i])) {
          def = 0;
        }
      }
      
      if (def) {
        p_kill(atoi(commands[0][1]), S_SIGTERM);
      } else if (!strcmp(commands[0][1], "-term")) {
        // fprintf(stderr, "SIGTERM FOR PID = %s\n", result->commands[0][2]);
        p_kill(atoi(commands[0][2]), S_SIGTERM);
      } else if (!strcmp(commands[0][1], "-stop")) {
        p_kill(atoi(commands[0][2]), S_SIGSTOP);
      } else if (!strcmp(commands[0][1], "-cont")) {
        p_kill(atoi(commands[0][2]), S_SIGCONT);
      }
}

void s_sleep(char** arg) {
  p_sleep(arg[1]);
  p_exit();
}

// run the echo function
void s_echo(char** words) {

  //1) if output file is null, then we write to stdout and do everything normally
  //2) if output file is not null but append is not true, then we overwrite the output file with the echo code
  //3) if output file is not null but append is true, then we append to the output file with the echo code
  
  int i = 1;
  char *word = words[i];
  while (word != NULL) {
    //fprintf(stderr, "%s ", word);
    f_write(currentRunningPcb->fdOut, word, strlen(word));
    i++;
    word = words[i];
  }
  //fprintf(stderr, "\n");
  f_write(currentRunningPcb->fdOut, "\n", strlen("\n"));

	p_exit();
}

// ZOMBIFY from writeup
void zombie_child() {
	// MMMMM Brains...!
	return;
}

void zombify() {
	char* argv[2] = {"zombie_child", NULL};
  char* name[] = {"zombify", NULL};
	p_spawn(zombie_child, argv, STDIN_FILENO, STDOUT_FILENO, name, 0);
	while (1);
	return;
}

// ORPHANIFY from writeup
void orphan_child() {
	while (1);
}

void orphanify() {
	char* argv[2] = {"orphan_child", NULL};
  char* name[] = {"orphanify", NULL};
	p_spawn(orphan_child, argv, STDIN_FILENO, STDOUT_FILENO, name, 0);
	return;
}

void man() {
	fprintf(stderr, "fg [job-id]\nbg [job-id]\nnice priority command [arg]\n");
	fprintf(stderr, "nice_pid priority pid\nman\njobs\nlogout\ncat\nsleep n\n");
	fprintf(stderr, "busy\necho\nls\ntouch file ...\nmv src dest\ncp src dest\n");
	fprintf(stderr, "rm file ...\nchmod\nps\nkill [ -SIGNAL_NAME ] pid ...\nzombify\norphanify\n");
}

/*
Sets the foreground process
Called from "fg" in the shell
*/
void s_fg(node *job, shellQueue *q, bool fromBackground) {
	// Sets foreground process
	foregroundProcess = job->pcb;

  if (!fromBackground) {
    p_kill(job->pcb->pid, S_SIGCONT);
  }
	// fprintf(stderr, "in s_fg: returning from p_kill\n");
	// Wait on the process
	int status;
	int nohang = false;

	p_waitpid(job->pcb->pid, &status, nohang);
	// fprintf(stderr, "in s_fg: returning from p_waitpid\n");
}

/*
Sets a background process
Called from "bg" in the shell
*/
void s_bg(node *job, shellQueue *q) {  
	p_kill(job->pcb->pid, S_SIGCONT);

	// fprintf(stderr, "in s_bg: returning from p_kill\n");
}

/*
Returns the pid of the spawned process
*/
int spawnProcessForNice (char*** commands, int fdIn, int fdOut, int priorityLevel) {
  char** cmdName = commands[2];
  char* cmd = commands[0][2];
  char* arg = commands[0][3];
    if (!strcmp(commands[0][0], "cat")) {

    } else if (!strcmp(cmd, "sleep")) {
        char *word = arg;
        if (word == NULL) {
          char* argv[1] = {NULL};
          return p_spawn(p_sleep, argv, STDIN_FILENO, STDOUT_FILENO, cmdName, priorityLevel);
        } else {
          return p_spawn(p_sleep, commands[0], STDIN_FILENO, STDOUT_FILENO, cmdName, priorityLevel);
        }
    } else if (!strcmp(cmd, "busy")) {

    } else if (!strcmp(cmd, "echo")) {
      // TODO: change to file system printf

      return p_spawn(s_echo, &commands[0][2], fdIn, fdOut, cmdName, priorityLevel);

    } else if (!strcmp(cmd, "ls")) {

    } else if (!strcmp(cmd, "touch")) {

    } else if (!strcmp(cmd, "mv")) {

    } else if (!strcmp(cmd, "cp")) {

    } else if (!strcmp(cmd, "rm")) {

    } else if (!strcmp(cmd, "chmod")) {

    } else if (!strcmp(cmd, "zombify")) {

    } else if (!strcmp(cmd, "orphanify")) {

    } 
    
    fprintf(stderr, "Invalid command: Not supported\n");
    return -1;
}


// ========================================
// FileSystem Functions
// ========================================
void s_touchCommand(char ** fileNames){
  f_touch(fileNames);
  p_exit();
}

void s_mvCommand(char ** argv) {
  f_mv(argv);
  p_exit();
}

void s_rmCommand(char ** fileNames){
  f_rm(fileNames);
  p_exit();
}

void s_cpCommand(char ** argv){
  f_cp(argv);
  p_exit();
}

void s_chmodCommand(char ** argv){
  f_chmod(argv);
  p_exit();
}

void s_lsCommand(char ** argv){
  int size = 0;
  while (argv[size] != NULL) {
      size++;
  }
  if (size > 2) {
    printf("ERROR: Syntax Error.\n");
    p_exit();
  }

  if (size == 2){
    char * output = f_ls(argv[1]);
    if (output != NULL){
      f_write(currentRunningPcb->fdOut, output, strlen(output));
    }
  } else {
    char * output = f_ls(NULL);
    if (output != NULL){
      f_write(currentRunningPcb->fdOut, output, strlen(output));
    }
  }
  p_exit();
}


void s_catCommand(char ** argv){
  int size = 0;
  while (argv[size] != NULL) {
      size++;
  }
  char * outputString = NULL;

  if (size == 1){
    outputString = (char *) calloc(4096, sizeof(char));
    int numBytes = 1;
    while(numBytes > 0){
      char * fileBuff = (char *) calloc(100, sizeof(char));
      numBytes = f_read(currentRunningPcb->fdIn, 100, fileBuff);
      strcat(outputString, fileBuff);
      // if (outputString[strlen(outputString) - 1] != '\n'){ //TODO: What will happen with files with this?
      //   printf("\n");
      //   break;
      // }
      free(fileBuff);
    }
  } else if (size > 1){
    int fileIndex = 1;
    outputString = (char *) calloc(4096, sizeof(char));
    while(argv[fileIndex] != NULL){
      char * fileName = argv[fileIndex];

      int fd = f_open(fileName, F_READ); //Opens at front of file 
      if (fd == -1){
        char * err_message = "CAT FILE ERROR, PLEASE MAKE SURE FILES ARE IN FileSystem.\n";
        f_write(STDOUT_FILENO, err_message, strlen(err_message));
        p_exit();
      }

      int numBytes = 1;
      char * fileBuff = (char *) calloc(100, sizeof(char));
      while(numBytes > 0){
        memset(fileBuff, 0, 100);
        numBytes = f_read(fd, 100, fileBuff);
        if (numBytes == -1){
          char * err_message = "CAT ERROR: File Error. Please Make Sure Files Are In FileSystem.\n";
          f_write(STDOUT_FILENO, err_message, strlen(err_message));
          p_exit();
        }
        if (strlen(fileBuff) > 0){
          // printf("LEN OUT: %d || LEN BUFF: %d\n", (int) strlen(outputString), (int) strlen(fileBuff));
          outputString = (char *) realloc(outputString, 4096 + strlen(outputString) + strlen(fileBuff));
          // printf("strcat checker 1\n");
          strcat(outputString, fileBuff);
          // printf("strcat checker 2\n");
        }
      }
      free(fileBuff);
      fileIndex++;
    }
  } else {
    f_write(STDOUT_FILENO, "ERROR.\n", 8);
    p_exit();
  }
  if (outputString != NULL){
    // printf("[Shell Funcs] FD OUT: %d || OUTPUT: %s || LEN: %lu\n", currentRunningPcb->fdOut, outputString, strlen(outputString));
    if(f_write(currentRunningPcb->fdOut, outputString, strlen(outputString)) == -1){
      f_write(STDERR_FILENO, "CAT OUT ERROR.\n", 16);
      p_exit();
    }
    // printf("\nPCB WRITE TEST: %d\n", outWriteTest);
    if (currentRunningPcb->fdOut == STDOUT_FILENO){
      f_write(currentRunningPcb->fdOut, "\n", 2);
    }
    free(outputString);
  } else {
    f_write(STDERR_FILENO, "CAT ERROR.\n", 12);
  }
  p_exit();
}