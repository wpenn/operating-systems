/**
The main shell file that controls reading and writing from the terminal
*/
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include <signal.h>
#include <fcntl.h>
#include "parser.h"
#include "queue.h"
#include "signal.h"
#include "shell_funcs.h"
#include "scheduler.h"
#include "userFuncs.h"
#include "node.h"
#include "shell.h"
#include "FileSystem/SystemCalls.h" //TODO: move from FileSystem folder into the root with the kernel files

char * filesystemName = "PennOsHarddrive";
int blocksInFat = 32;
int blockSizeConfig = 4;

void setupShellQueue() {
  q = malloc(sizeof(shellQueue));
  job_id = 1;
}

/*
Main logic for the shell process
*/
void runShellLoop () {
  char cmd[MAX_LINE_LENGTH];
  int numBytes;

	q->backgroundQueue = NULL;
	q->stoppedQueue = NULL;

  //Set up FileSystem: Create FS And Mount
  f_mkfs(filesystemName, blocksInFat, blockSizeConfig);
  f_mount(filesystemName);

  // start the prompt loop
	while(1) {

 		if (f_write(STDERR_FILENO, PROMPT, strlen(PROMPT)) == -1) {
      perror("ERROR: writing prompt\n");
    }

    // TODO: replace with f_read();
    numBytes = f_read(STDIN_FILENO, MAX_LINE_LENGTH, cmd);

		// If there are background processes, we wait on all of them
		if (!backgroundIsEmpty(q)) {
      int ret = 0;
      node *temp = q->backgroundQueue;
      int wstatus;
      while (temp != NULL && ret >= 0) {
        pid_t pid = temp->pcb->pid;
        int nohang = true;
        // wait on the process
        ret = p_waitpid(pid, &wstatus, nohang);

        // If the background process has finished
        if (ret > 0) {
          f_write(STDERR_FILENO, "Finished: ", strlen("Finished: "));
          printCurrCommand(temp);
          f_write(STDERR_FILENO, "\n", strlen("\n"));

          // Pop the finished node from the background queue
          node* done = popForBgWithId(q, temp->job_id);
          freeNode(done);
        }
        temp = temp->next; 
      }
		}
    
    // check if control D was pressed and exit if it was
		if (numBytes == -1 || numBytes == 0 || cmd[0] == '\0') {
      f_write(STDERR_FILENO, "\n", strlen("\n"));
      exit(0);
			p_exit();
		} 

    if (cmd[0] == '\n') {
			continue;
		}

    // handle the case when the user types a command then presses control D
		if (cmd[numBytes - 1] != '\n') {
			// fprintf (stderr, "\n"); -- write a new line to terminal
			cmd[numBytes] = '\n';
		} 

    // add the null terminator
  	cmd[numBytes] = '\0';

    executeCommand(cmd, NULL, NULL);
  }
}

void s_script(char ** argv) {
  // make list of string tokens from the passed in file
  executeCommand(argv[0], NULL, &currentRunningPcb->fdOut);
  p_exit();
}

void executeCommand(char * cmd, int * overWriteFDIN, int * overWriteFDOUT){
    struct parsed_command *result;
    int successParsing = parse_command(cmd, &result);

    if (successParsing >= 1) {
      // print Invalid -- log invalid?
      f_write(STDERR_FILENO, "invalid command\n", strlen("invalid command\n"));
    }

    int fdIn = STDIN_FILENO;
    int fdOut = STDOUT_FILENO;
    if (result->stdin_file != NULL) {
      fdIn = f_open((char *) result->stdin_file, F_READ);
      if (fdIn == -1) {
        f_write(STDOUT_FILENO, "STRDIN File Error. Make sure file is in Filesystem.\n", 53); //TODO: replace with write to stderr_fileno
        // fdIn = STDERR_FILENO;
        return;
      }
    } else if (overWriteFDIN != NULL) {
      fdIn = *overWriteFDIN;
    }

    // printf("STDOUT FILE: %s\n", result->stdout_file);
    if (result->stdout_file != NULL) {
      // printf("[0 Shell] FD OUT: %d\n", fdOut);
      if (result->is_file_append) {
        fdOut = f_open((char *) result->stdout_file, F_APPEND); 
      } else {
        fdOut = f_open((char *) result->stdout_file, F_WRITE);
      }
      // printf("[1 Shell] FD OUT: %d\n", fdOut);
      if (fdOut == -1) {
        // perror("open");
        f_write(STDOUT_FILENO, "STDOUT File Error. Make sure file is in Filesystem.\n", 53); //TODO: replace with write to stderr_fileno
        // fdOut = STDOUT_FILENO;
        return;
      }
    } else if (overWriteFDOUT != NULL){
      fdOut = *overWriteFDOUT;
    }
  int pid = -1;
  int needToWait = 1;
  if (!strcmp(result->commands[0][0], "fg")) {
    node *job;
    bool fromBackground = false;
    // get the specific job by id from either stopped or background
    if (result->commands[0][1] != NULL) {
      job = popForFgFromStoppedWithId(q, atoi(result->commands[0][1]));

      if (job == NULL) {
        fromBackground = true;
        job = popForFgFromBackgroundWithId(q, atoi(result->commands[0][1]));
      } else {
        f_write(STDERR_FILENO, "Restarting: ", strlen("Restarting: "));
        printCurrCommand(job);
      }
    }  else {
      // pop the first stopped or background job
      job = popForFgFromStopped (q);
      if (job == NULL) {
        fromBackground = true;
        job = popForFgFromBackground (q);
      } else {
        f_write(STDERR_FILENO, "Restarting: ", strlen("Restarting: "));
        printCurrCommand(job);
      }
    }

    if (job != NULL) {
      s_fg(job, q, fromBackground);
    } else {
      f_write(STDERR_FILENO, "Invalid: no job stopped or in background\n", strlen("Invalid: no job stopped or in background\n"));
    }
    needToWait = 0;
  } else if (!strcmp(result->commands[0][0], "bg")) {
    node *job;
    // If job_id is specified
    if (result->commands[0][1] != NULL) {
      job = pushJobToBgFromStoppedWithId(q, atoi(result->commands[0][1]));
    } else {
      // Push most recently stopped job to Background Queue
      job = pushJobToBgFromStopped(q);
    }

    if (job != NULL) {
      f_write(STDERR_FILENO, "Restarting: ", strlen("Restarting: "));
      printCurrCommand(job);
      s_bg(job, q);
    } else {
      f_write(STDERR_FILENO, "Invalid: no job stopped or in background\n", strlen("Invalid: no job stopped or in background\n"));
    }

    needToWait = 0;

  } else if (!strcmp(result->commands[0][0], "jobs")) {
    printJobs(q);
    needToWait = 0;
  } else if (!strcmp(result->commands[0][0], "sleep")) {
    // TODO: need to check for if a second arg is passed in ?
    if (result->commands[0][1] == NULL) {
      f_write(STDERR_FILENO, "Invalid command\n", strlen("Invalid command\n"));
    } else {
      pid = p_spawn(s_sleep, result->commands[0], STDIN_FILENO, STDOUT_FILENO, result->commands[0], 0);
    }

  } else if (!strcmp(result->commands[0][0], "busy")) {

  } else if (!strcmp(result->commands[0][0], "echo")) {

    pid = p_spawn(s_echo, result->commands[0], fdIn, fdOut, result->commands[0], 0);

  } else if (!strcmp(result->commands[0][0], "touch")) {
    int size = 0;
    while (result->commands[0][size] != NULL) {
        size++;
    }

    if (size == 1) {
      f_write(STDERR_FILENO, "ERROR: Syntax Error.\n", strlen("ERROR: Syntax Error.\n"));
      return;
    }
    
    char ** fileNames = (char**)calloc(sizeof(char *) * size + 1, sizeof(char *));
    int index = 1;
    while (index < size) {
      fileNames[index - 1] = result->commands[0][index];
      index++;
    }
    pid = p_spawn(s_touchCommand, fileNames, fdIn, fdOut, result->commands[0], 0);

  } else if (!strcmp(result->commands[0][0], "cat")) {
    pid = p_spawn(s_catCommand, result->commands[0], fdIn, fdOut, result->commands[0], 0);
  } else if (!strcmp(result->commands[0][0], "ls")) {
    pid = p_spawn(s_lsCommand, result->commands[0], fdIn, fdOut, result->commands[0], 0);
  } else if (!strcmp(result->commands[0][0], "mv")) {
    int size = 0;
    while (result->commands[0][size] != NULL) {
        size++;
    }
    if (size != 3) {
      f_write(STDERR_FILENO, "ERROR: Syntax Error.\n", strlen("ERROR: Syntax Error.\n"));
      return;
    }
    char * argv[3] = {result->commands[0][1], result->commands[0][2], NULL};
    pid = p_spawn(s_mvCommand, argv, fdIn, fdOut, result->commands[0], 0);
  } else if (!strcmp(result->commands[0][0], "cp")) {
    int size = 0;
    while (result->commands[0][size] != NULL) {
      size++;
    }
    if (size != 3) {
      f_write(STDERR_FILENO, "ERROR: Syntax Error.\n", strlen("ERROR: Syntax Error.\n"));
      return;
    }

    char * argv[3] = {result->commands[0][1], result->commands[0][2], NULL};
    pid = p_spawn(s_cpCommand, argv, fdIn, fdOut, result->commands[0], 0);
    
  } else if (!strcmp(result->commands[0][0], "rm")) { //TODO: ERROR - IF YOU [ rm fileInSystem fileNotInSystem ], then it clears the binary file when you next mount
    int size = 0;
    while (result->commands[0][size] != NULL) {
        size++;
    }
    if (size == 1) {
      f_write(STDERR_FILENO, "ERROR: Syntax Error.\n", strlen("ERROR: Syntax Error.\n"));
      return;
    }

    char ** fileNames = (char**)calloc(sizeof(char *) * size + 1, sizeof(char *));
    int index = 1;
    while (index < size) {
      fileNames[index - 1] = result->commands[0][index];
      index++;
    }
    pid = p_spawn(s_rmCommand, fileNames, fdIn, fdOut, result->commands[0], 0);
  } else if (!strcmp(result->commands[0][0], "chmod")) {
    int size = 0;
    while (result->commands[0][size] != NULL) {
        size++;
    }
    if (size != 3) {
      f_write(STDERR_FILENO, "Invalid number of commands\n", strlen("Invalid number of commands\n"));
      return;
    }

    pid = p_spawn(s_chmodCommand,  result->commands[0], fdIn, fdOut, result->commands[0], 0);
  } else if (!strcmp(result->commands[0][0], "kill")) {

    s_kill(result->commands);
    needToWait = 0;

  } else if (!strcmp(result->commands[0][0], "zombify")) {
    zombify();
  } else if (!strcmp(result->commands[0][0], "orphanify")) {

  } else if (!strcmp(result->commands[0][0], "nice")) {
    if (result->commands[0][1] != NULL) {
      int priorityLevel = atoi(result->commands[0][1]);
      if (priorityLevel < -1 || priorityLevel > 1) {
        f_write(STDERR_FILENO, "Invalid command bad priority level\n", strlen("Invalid command bad priority level\n"));
        needToWait = 0;
      } else {
        pid = spawnProcessForNice(result->commands, fdIn, fdOut, priorityLevel);

        // If we received an invalid command
        if (pid == -1) {
          needToWait = 0;
        }
      }
    }
  } else if (!strcmp(result->commands[0][0], "nice_pid")) {
    f_write(STDERR_FILENO, "nice_pid\n", strlen("nice_pid\n"));
    // needToWait = 0; // TODO: SEGFAULT
  } else if (!strcmp(result->commands[0][0], "man")) {
    man();
    needToWait = 0;
  } else if (!strcmp(result->commands[0][0], "logout")) {
    //TODO: f_unmount
    exit(EXIT_SUCCESS);
  } else if (!strcmp(result->commands[0][0], "ps")) {
    pid = p_spawn(ps, result->commands[0], fdIn, fdOut, result->commands[0], 0);

    needToWait = 1;
  } else {
    int size = 0;
    while (result->commands[0][size] != NULL) {
        size++;
    }
    if (size == 1){
      int scriptFd = f_open(result->commands[0][0], F_READ);
      if (scriptFd == -1){
        f_write(STDERR_FILENO, "Script Error: Script File Does Not Exist.\n", 43);
      } else { //TODO: WESLEY --> CHECK fd permissions
        char * fileString = (char *) calloc(4096, sizeof(char));
        int numBytes = 1;
        while(numBytes > 0){
          char * lineBuff = (char *) calloc(100, sizeof(char));
          numBytes = f_read(scriptFd, 100, lineBuff);
          if (numBytes >= 0){
            fileString = (char *) realloc(fileString, 4096 + strlen(lineBuff) + strlen(fileString));
            strcat(fileString, lineBuff);
          }
          free(lineBuff);
        }
        
        char * argv[2] = {"jljlk", NULL}; //TODO: WESLEY arguments
        pid = p_spawn(s_script, argv, fdIn, fdOut, result->commands[0], 0);
      }
    } else {
      f_write(STDERR_FILENO, "Invalid command: Not supported\n", strlen("Invalid command: Not supported\n"));
    }
  }
  
  // Shell waiting
  if (!result->is_background && needToWait) {
    int wstatus;
    int ret = -1;
    element * pidPcb = findElementInQueues(pid);
    if (pidPcb == NULL){
      return;
    }
    foregroundProcess = ((pcb*) pidPcb->value);
    ret = p_waitpid(pid, &wstatus, false);
  } else if (result->is_background && needToWait) {
    element * pidPcb = findElementInQueues(pid);
    if (pidPcb == NULL){
      return;
    }
    pcb* newBackgroundPcb = ((pcb*) findElementInQueues(pid)->value);
    
    // Add a new node to the background queue
    node* job = makeNode(job_id, newBackgroundPcb);
    pushNewJobToBg (q, job);

    f_write(STDERR_FILENO, "Running: ", strlen("Running: "));
    printCurrCommand(job);
    f_write(STDERR_FILENO, "\n", strlen("\n"));

    job_id++;
  }

  needToWait = 1;
}
