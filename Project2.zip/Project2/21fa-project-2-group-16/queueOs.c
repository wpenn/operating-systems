#include <stdlib.h>
#include <stdio.h>
#include "pcb.h"
#include "queueOs.h"

/*
SCHEDULER LEVEL QUEUES
*/

/*
Creates a generic element for the queue
- node is the new element
- next is set to NULL
*/
element* makeElement(void *node) {
  element* new_node = (element*) malloc(sizeof(element));
  // Assumes that value is already malloced outside of this
  new_node->value = node;
  new_node->next = NULL;
  return new_node;
}

/*
Checks if queue is empty
Returns:
  0: not empty
  1: empty
*/
int isEmpty(queue* q) {
  return q == NULL || q->head == NULL;
}

/*
Pops from the front of the queue and returns the element
*/
element* popFromFront(queue* q) {
  if (isEmpty(q)) {
    return NULL;
  }

  q->size--;
  element* tmp = q->head;
  // Removes the first element, sets queue to start at the next element
  q->head = q->head->next;
  return tmp;
}

/*
pop the first ready process from the queue
*/
pcb* popFirstReadyProcess(queue *q) {
  if (isEmpty(q)) {
    return NULL;
  }

  element* currElt = q->head;

  // if the first process is ready pop that off the queue
  // CHECK HERE IF THERE IS A FIRST ELEMENT AND ITS STATUS IS NOT READY
  if (((pcb*) (currElt->value))->status == READY) {
    element* e = popFromFront(q);
    pcb* currPcb = (pcb*) e->value;
    free(e);
    return currPcb;
  }

  // if we find a ready process, take the elt out of the queue and return its pcb
  while (currElt->next != NULL) {
    pcb* currPcb = (pcb*) currElt->next->value;
    if (currPcb->status == READY) {
      element* nextElt = currElt->next;
      currElt->next = currElt->next->next;
      q->size--;
      free(nextElt);
      return currPcb;
    }
    
    currElt = currElt->next;
  }

  return NULL;
}

/*
Pushes to back of the queue.
Assumes that node had makeElement called on it.
*/
void pushToBack(queue* q, element *e) {
  // If the queue is empty, set queue to be the element
  if (isEmpty(q)) {
    q->size++;
    q->head = e;
    return;
  }

  // If the queue is not empty, add to the next spot at the end
  element *tmp = q->head;
  while (tmp->next != NULL) {
    tmp = tmp->next;
  }
  tmp->next = e;

  q->size++;
}

/*
Pop from queue with given pid
*/
pcb* popWithPid(queue* q, int pid) {
  if (isEmpty(q)) {
    return NULL;
  }
  element* tmp = q->head;
  pcb* currPcb = ((pcb*) tmp->value);

  // If the queue is length 1
  if (tmp->next == NULL) {
    if (currPcb->pid == pid) {
      q->head = NULL;
      return currPcb;
    }
  }

  
  // If the queue is greater than length 1
  while (tmp->next != NULL) {
    pcb* currPcb = (pcb*) tmp->next->value;
    if (currPcb->pid == pid) {
      element *e = tmp->next;
      tmp->next = tmp->next->next;
      // TODO: free element
      free (e);
      return currPcb;
    }
    tmp = tmp->next;
  }
  return NULL;
}

/*
Prints the contents of a queue
For now, int input to specify the type (bc void* generic)
type = 0 is PCB
*/
void printQueue(queue* q, int type) {
  if (isEmpty(q)) {
    return;
  }
  
  // If printing PCB types
  if (type == PCB_TYPE) {
    element *tmp = q->head;
    while (tmp != NULL) {
      // fprintf(stderr, "Printing pcb\n");
      if (tmp->value == NULL) {
        fprintf (stderr, "temp value is null in print queue\n");
      }
      
      printPcb((pcb*) tmp->value);
      tmp = tmp->next;
    }
  }

  // Put other potential non PCB types here
}

/*
PCB-specific function (for now)
Find a pcb element in the queue given a pcb
*/
element* findPcbElement(queue* q, int pid) {
  element *tmp = q->head;
  while (tmp != NULL) {
    pcb* tmpPcb = (pcb*) tmp->value;
    if (tmpPcb->pid == pid) {
      return tmp;
    }
    tmp = tmp->next;
  }
  return NULL;
}



