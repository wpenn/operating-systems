#include "pcb.h"
#include "queueOs.h"

static const int millisecond = 1000; 
int total_ticks;

ucontext_t *schedulerFuncContext;
ucontext_t *idleProcessContext;

pcb* idleProcessPcb;

pcb* currentRunningPcb;
pcb* foregroundProcess;

queue *highestPQ;
queue *middlePQ;
queue *lowestPQ;

queue *completedQ;
queue *stoppedQ;

bool scheduledIdle;

queue* getStoppedQ();

void printQueues();

pcb* getForeground();

void setForegroundProcess(pcb* f);

queue* getStoppedQ();

void setupQueues();

void setupContexts();

pcb* nextProcessToRun();

void printAllQueues();

void processTimeout();

// used by p_spawn to know where to add the pcb
pcb* getCurrentRunningPcb ();

void addProcessToQueue (pcb* pcb, int priorityLevel);

pcb* getPcb (int pid);

// called when process terminates before alarm call
void processCompleted();

// void pushToCompletedQ(pcb* pcb);

// stores the completed process in an overall queue
void addToCompletedQueue(pcb* pcb);

// schedule the next process to run
void schedule();

// check if the inputted pid number has completed
pcb* findCompletedProcess(int pid);

// finds the element in the queue for signalling purposes
element* findElementInQueues(int pid); 

// looks for sleep commands that have been running long enough
void checkForCompletedSleepProcesses(queue *q);

// moves around the elements in the queues
void k_nice(int pid, int priority);

void removePcb(int pid);

void findAndRemovePcb(pcb *node);

void clock_ticks();

int getTicks();

void changeProcessState(int pid, pcb* p, int newState);

void printForPs();

void alarmHandler();