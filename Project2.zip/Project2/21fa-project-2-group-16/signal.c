#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <stdlib.h>
#include "userFuncs.h"
#include "signal.h"
#include "scheduler.h"
#include "logFuncs.h"

/*
Registers our signal handlers
Called from main.c
*/
void registerSignalHandlers() {
	if (signal (SIGINT, signalHandler) == SIG_ERR) {
		fprintf(stderr, "Unable to catch SIGINT\n");
	}

	// catch CTRL Z
	if (signal (SIGTSTP, signalHandler) == SIG_ERR) {
		fprintf(stderr, "Unable to catch SIGTSTP\n");
	}

	// catch SIGGTOU (tries to read from output)
	if (signal (SIGTTOU, SIG_IGN) == SIG_ERR) {
		fprintf(stderr, "Unable to catch SIGTTOU\n");
	}
}


/** 
* Handles signals sent to the parent process
* 
* @param signum - the int id of the signal passed into the handler
*/
void signalHandler(int signum) {
	fprintf(stderr, "\n");
	
	if (signum == SIGINT) {
		// Catch CTRL-C
		fprintf(stderr, "\nhandling sigint\n");
		exit(0);
		fprintf(stderr, "currentRunningPcb is null: %d\n", currentRunningPcb == NULL);
		fprintf(stderr, "currentRunningPcb->pid: %d\n", currentRunningPcb->pid);
		fprintf(stderr, "foregroundProcess is null: %d\n", foregroundProcess == NULL);
		fprintf(stderr, "foregroundProcess->pid: %d\n", foregroundProcess->pid);
		// if (currentRunningPcb->pid == 1) {
		// 	fclose(getFile());
		// }
		// fprintf(stderr, "going into pkill\n");
		if (foregroundProcess != NULL && foregroundProcess->pid != 1) {
			fprintf(stderr, "in this part not supposed to be here\n");
			p_kill(foregroundProcess->pid, S_SIGTERM); 
		} else {
			fprintf(stderr, "don't kill the shell\n");
		}
	} else if (signum == SIGTSTP) {
		// Catch CTRL-Z
		fprintf (stderr, "handling sig stop\n");

		if (foregroundProcess != NULL && foregroundProcess->pid != 1) {
			p_kill(foregroundProcess->pid, S_SIGSTOP);
			fprintf (stderr, "coming back to handler\n");
		} else {
			// Don't stop the shell, rewrite the prompt though
			write (STDERR_FILENO, PROMPT, strlen(PROMPT));
		}
		

// i dont wanna delete but do we need all tehse signals??
	} else if (signum == SIGTTIN) {
		fprintf (stderr, "handling sigttin\n");
		
	} else if (signum == SIGTTOU) {
		fprintf (stderr, "handling sigttou\n");
	} else if (signum == SIGQUIT) {
		fprintf (stderr, "handling sigquit\n");
	} else if (signum == SIGALRM) {
		fprintf(stderr, "alarm went off\n");
	}
}
