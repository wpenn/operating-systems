#ifndef SIGNALS
#define SIGNALS

#define S_SIGSTOP 1 // a thread receiving should be stopped
#define S_SIGCONT 2 // a thread receiving should be continued
#define S_SIGTERM 3 // a thread receiving should be terminated

void registerSignalHandlers();

void signalHandler(int signum);

#endif

