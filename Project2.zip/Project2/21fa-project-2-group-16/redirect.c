#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>

// handle an input redirect
int redirectInput (const char *stdin_file) {
  int new_stdin;
  new_stdin = open(stdin_file, O_RDONLY);

  if (new_stdin == -1) {
    perror ("open");
  }

  int success = dup2(new_stdin, STDIN_FILENO);
  if (success == -1) {
    perror ("dup2");
  }

  return success;
}
 
// handle an output redirect
int redirectOutput (const char *stdout_file, int is_file_append) {
  int new_stdout;

  // determine whether or not to append to the output file or clear
  if (is_file_append) {
    new_stdout = open(stdout_file, O_CREAT | O_WRONLY | O_APPEND, 0644);
  } else {
    new_stdout = open(stdout_file, O_CREAT | O_WRONLY | O_TRUNC, 0644);
  }

  if (new_stdout == -1) {
    perror("open");
  }
  
  int success = dup2(new_stdout, STDOUT_FILENO);
  if (success == -1) {
    perror ("dup2");
  }

  return success;
}

void handleRedirects (int childNumber, int totalChildren, const char *stdin_file, const char *stdout_file, int is_file_append) {
  // check for input file redirection and edit file descriptor table
  if (childNumber == 0 && stdin_file != NULL) {
    redirectInput(stdin_file);
  }

  // check for output file redirection and edit file descriptor table
  if (childNumber == totalChildren - 1 && stdout_file != NULL) {
    redirectOutput(stdout_file, is_file_append);
  }
}