#include <stdlib.h>
#include <stdio.h>
#include "node.h"

#ifndef SHELLQUEUE 
#define SHELLQUEUE

typedef struct shell_queue_struct {
  node *backgroundQueue;
  node *stoppedQueue;
} shellQueue;

void pushStoppedJob (shellQueue *q, node *job);

void pushNewJobToBg (shellQueue *q, node *job);

node* pushJobToBgFromStopped (shellQueue *q);

node* pushJobToBgFromStoppedWithId (shellQueue *q, int job_id);

node* popForFg (shellQueue *q);

node* popForFgFromBackground (shellQueue *q);

node* popForFgFromStopped (shellQueue *q);

node* popForFgFromStoppedWithId (shellQueue *q, int job_id);

node* popForFgFromBackgroundWithId (shellQueue *q, int job_id);

node* popForFgWithId (shellQueue *q, int job_id);

node* popStoppedJob (shellQueue *q);

node* popBgJob (shellQueue *q);

node* popForStoppedWithId (shellQueue *q, int job_id);

node* popForBgWithId (shellQueue *q, int job_id);

int backgroundIsEmpty (shellQueue *q);

int stoppedIsEmpty(shellQueue *q);

node* makeNode(int job_id, pcb* pcb);

void printCurrCommand (node* n);

// void printCurrCommandGroup (node* n);

void printJobs(shellQueue *q);

void printBackgroundQueue(shellQueue *q);

void printStoppedQueue(shellQueue *q);

node* findNode(shellQueue* q, int pid);

void freeQueue(shellQueue *q);

void freeNode(node* n);

#endif