#include "pcb.h"
#include <ucontext.h>
#include <stdbool.h>
#include <stddef.h>
#include <signal.h>
#include "scheduler.h"
#include "kernelFuncs.h"
#include <signal.h>
#include <sys/time.h> 
#include "shell.h"
#include "signal.h"
#include "logFuncs.h"

#define STACK_SIZE 16384

/*
Fills up the ucontext_t stack
*/
void fillUContextStack(ucontext_t *uc, void *sp) {
  sp = malloc(STACK_SIZE);
  uc->uc_stack.ss_sp = sp;
  uc->uc_stack.ss_size = STACK_SIZE;
  uc->uc_stack.ss_flags = 0;
  return;
}

/*
Counts the number of arguments in argv[]
*/
int countNumArgs (char *argv[]) {
  int i = 0;
  while (argv[i] != NULL) {
    i++;
  }

  return i;
}

/*
Spawns a new child process and sets up its context
*/
pid_t p_spawn(void (*func)(), char *argv[], int fd0, int fd1, char** cmd, int priorityLevel) {
  ucontext_t *uc = malloc(sizeof(ucontext_t));
  getcontext(uc);

  void *sp = NULL;
  fillUContextStack(uc, sp);

  // For masking signals for the shell: KEEP HERE FOR NOW
  if (func == runShellLoop) {
    // Masking CTRL-C and CTRL-Z for the shell
    // fprintf(stderr, "shell mask\n");
    sigset_t maskedSignals;
    sigemptyset(&maskedSignals);
    sigaddset(&maskedSignals, SIGINT);
    sigaddset(&maskedSignals, SIGTSTP);

    uc->uc_sigmask = maskedSignals;
  } else {
    sigemptyset(&(uc->uc_sigmask));
  }

  // sigemptyset(&(uc->uc_sigmask)); // Change to what's commented out above later
  
  uc->uc_link = schedulerFuncContext; 


  int numFuncArgs = countNumArgs (argv);
  makecontext(uc, func, numFuncArgs, argv);
  
  // Parent pcb of this child thread
  pcb *parent = currentRunningPcb;

  // Create a new child pcb
  pcb* child = k_process_create(parent, priorityLevel, cmd, fd0, fd1);
  child->ucontext = uc;

  // Add child pcb to the parent pcb's children array
  if (parent != NULL) {
    int i = 0;
    while (parent->childPids[i] != 0 && i < 100) {
      i++;
    }
    parent->childPids[i] = child->pid;
  }
  // foregroundProcess = child; // is this here
  return child->pid;
}

/*
If nohang is false, sets the calling thread as blocked
If nohang is true, returns immediately
Returns pid of child which has changed state on success, -1 on error
*/
pid_t p_waitpid(pid_t pid, int *wstatus, bool nohang) {
  // need to add a signal mask here ebcause it needs to set its status to blocked so it 
  // doesn't get scheduled again after echo and do things out of order
  if (!nohang) {
    // Block the shell process
    currentRunningPcb->status = BLOCKED;
    logBlocked(getTicks(), currentRunningPcb->pid, currentRunningPcb->priorityLevel, currentRunningPcb->command);
    // Add the shell process back to the queue (for scheduler to schedule again after child finishes)
    addProcessToQueue(currentRunningPcb, currentRunningPcb->priorityLevel);
    
    // Switch from this shell process to the scheduler
    swapcontext(currentRunningPcb->ucontext, schedulerFuncContext);
  }

  pcb* completedChild = findCompletedProcess(pid);
  
  if (!nohang) {
    if (completedChild != NULL && completedChild->status == ZOMBIED && completedChild->statusChanged) {
      *wstatus = ZOMBIED;
      k_process_cleanup(completedChild);
      return pid;
    } else {
      element* childElt = findElementInQueues(pid);
      pcb* p = (pcb*) childElt->value;
      if (p->statusChanged) {
        *wstatus = p->status;
        fprintf (stderr, "child status changed from waitpid\n");
        // TODO: do different things in the parent based on this status change

        return p->pid;
      }
    }
  }
  if (completedChild != NULL) {
    return completedChild->pid;
  }
  
  return -1;
}

/*
Sends the signal sig to the thread referenced by pid
returns 0 if killed succesfully, -1 on error
*/
int p_kill (pid_t pid, int sig) {
  // fprintf(stderr, "In p_kill, received signal %d with pid %d\n", sig, pid);
  // If the pid is the currentRunningPcb, it will not be in any queues

  if (pid == currentRunningPcb->pid) {
    k_process_kill(currentRunningPcb, sig);
    fprintf(stderr, "back in p_kill\n");
    return 0;
  }

  // Find the pcb with pid
  pcb* killPcb = getPcb(pid);

  // Call k_process_kill on that pcb
  if (killPcb != NULL) {
    //fprintf(stderr, "in p_kill: calling k_process_kill on pid %d\n", killPcb->pid);
    k_process_kill(killPcb, sig);
    fprintf(stderr, "back in p_kill\n");
    return 0;
  }
  fprintf(stderr, "Error sending signal %d to pid %d\n", sig, pid);
  return -1; // Error
}
  

/*
Called when a process is done running
adds it to the completed queue to be waited on later by its parent
*/
void p_exit() {
  processCompleted();
}

void p_setTerminalControl(pid) {
  
}

// moves a process to a different priority level
int p_nice(pid_t pid, int priority) {
  k_nice(pid, priority);
  return 0;
}

// process that just suspends itself
void idleProcess() {
  sigset_t mask;
  sigemptyset(&mask);
  sigsuspend(&mask);
  
  // fprintf(stderr, "helgjafae\n");
  
}

// sleep process
void p_sleep(char *t) {
  
  int ticks = atoi(t)*10;
  int starting_ticks = getTicks();
  // fprintf(stderr, "in p_sleep: currentRunningPcb pid is %d\n", currentRunningPcb->pid);
  currentRunningPcb->startingTick = starting_ticks;
  currentRunningPcb->numTicks = ticks;
  // fprintf(stderr, "has startingTick of %d\n", currentRunningPcb->startingTick);
  // fprintf(stderr, "has numTicks of %d\n", currentRunningPcb->numTicks);

  currentRunningPcb->status = BLOCKED;
  logBlocked(getTicks(), currentRunningPcb->pid, currentRunningPcb->priorityLevel, currentRunningPcb->command);
  
  alarmHandler();
  

  // while (currentRunningPcb->status == BLOCKED) {
    // printf(stderr, "currentRunningPcb of pid %d is blocked\n", currentRunningPcb->pid);
    // fprintf(stderr, "has startingTick of %d\n", currentRunningPcb->startingTick);
    // fprintf(stderr, "has numTicks of %d\n", currentRunningPcb->numTicks);
  // }

  // addProcessToQueue(currentRunningPcb, currentRunningPcb->priorityLevel);
  // Switch from this shell process to the scheduler
  // fprintf(stderr, "\nin p_sleep, printing all queues\n");
  // printAllQueues();
  // swapcontext(currentRunningPcb->ucontext, schedulerFuncContext);
  

  // if (ticks == 0) {
  //   idleProcess();
  // } else {
  //   int n_ticks = getTicks();
  //   while(n_ticks < (starting_ticks + ticks)) {
  //     n_ticks = getTicks();
  //   }
  //   p_exit();
  // }
}

/*
User level functions/macros depending on status returned from p_waitpid
*/
int W_WIFEXITED(int status) {
  // If zombied or orphaned we have exited ?
  return status == 4 || status == 5 ? 1 : 0;
}

int W_WIFSTOPPED(int status) {
  // If stopped
  return status == 3 ? 1 : 0;
}

int W_WIFSIGNALED(int status) {
  // Return true if the child was terminated by a signal,
  // that is, by a call to p_kill with the S_SIGTERM signal
  return status == 3 ? 1 : 0;
}
