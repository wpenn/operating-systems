#include "pcb.h"
#include <ucontext.h>
#include <stdbool.h>

pid_t p_spawn(void (*func)(), char *argv[], int fd0, int fd1, char **cmd, int priorityLevel);

pid_t p_waitpid(pid_t pid, int *wstatus, bool nohang);

int p_kill(pid_t pid, int sig);

void p_exit();

void fillUContextStack(ucontext_t *uc, void *sp);

void p_sleep(char *t);

int p_nice(pid_t pid, int priority);

void p_setTerminalControl(int pid);

void idleProcess();

int W_WIFEXITED(int status);

int W_WIFSTOPPED(int status);

int W_WIFSIGNALED(int status);