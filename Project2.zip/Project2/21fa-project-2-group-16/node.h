#include <stdlib.h>
#include "pcb.h"

#ifndef NODE 
#define NODE
typedef struct node_struct {
    int job_id;
    pcb* pcb;
    struct node_struct *next;
} node;
#endif