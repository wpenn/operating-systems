#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <stdlib.h>
#include "kernelFuncs.h"
#include "scheduler.h"
#include "queueOs.h"
#include "signal.h"
#include "logFuncs.h"
#include "node.h"
#include "queue.h"
#include "shell.h"

pid_t currentPid = 1;

/*
Kernel-level function to create a pcb for the child thread
*/
pcb* k_process_create(pcb *parent, int priorityLevel, char** cmd, int fdIn, int fdOut) {

  int parentPID = 0;
  ucontext_t uc;
  if (parent != NULL) {
    uc = *parent->ucontext;
    parentPID = parent->pid;
  }

  pcb *p = NULL;

  // Create the child pcb and add it to the priority queue
  p = createPcb (currentPid, parentPID, fdIn, fdOut, &uc, priorityLevel, cmd);
  addProcessToQueue (p, priorityLevel);

  logCreate(getTicks(), p->pid, p->priorityLevel, p->command);
  
  currentPid ++;
  return p;
}

/*
Sends signal to process
*/
int k_process_kill(pcb *process, int signal) {
	if (signal == S_SIGSTOP) {
    fprintf(stderr, "In k_process_kill, handling S_SIGSTOP\n");

    // Make sure when a process finishes it is not a foreground process anymore
    // If foreground process is not the shell
    if (foregroundProcess->pid != 1) {
      foregroundProcess = getPcb(1);
      logStopped(getTicks(), process->pid, process->priorityLevel, process->command);
      process->status = STOPPED;

      if (!strcmp(process->command[0], "sleep")) {
        // Update numTicks to be the numTicks left for sleep at this point
        process->numTicks = process->numTicks - (getTicks() - process->startingTick);
        // fprintf(stderr, "numTicks is now %d\n", process->numTicks);
      }


      // Add current process to the stopped queue
      node *stoppedJob = makeNode(job_id, process);
      job_id++;
      fprintf(stderr, "\nStopped: ");
      printCurrCommand(stoppedJob);
      
      fprintf(stderr, "\n");

      pushStoppedJob(q, stoppedJob);

      pcb* parent = getPcb(process->parentPID);
      parent->status = READY;
      printAllQueues();
    }
    return 0;

	} else if (signal == S_SIGCONT) {
    fprintf(stderr, "In k_process_kill, handling S_SIGCONT\n");
    logContinued(getTicks(), process->pid, process->priorityLevel, process->command);

    // if process == stopped 
    if (process->status == STOPPED) {
      process->status = READY;

      if (!strcmp(process->command[0], "sleep")) {
        process->status = BLOCKED;
        // Update the starting tick to be the current tick for sleep
        // fprintf(stderr, "updating starting tick to %d\n", getTicks());
        process->startingTick = getTicks();
      }

      pcb* parent = currentRunningPcb;
      if (process->parentPID != currentRunningPcb->pid) {
        parent = getPcb(process->parentPID);
      }
      
      // Check if foregroundProcess is shell
      if (process->pid == foregroundProcess->pid) {
        parent->status = BLOCKED;
      }
     
      logBlocked(getTicks(), parent->pid, parent->priorityLevel, parent->command);
      
    }
    return 0;
	} else if (signal == S_SIGTERM) {
    // fprintf(stderr, "In k_process_kill, handling S_SIGTERM\n");
    
    // remove from queue 
    // findAndRemovePcb(process);
    // log file
    logSignaled(getTicks(), process->pid, process->priorityLevel, process->command);
    
    // fprintf(stderr, "foregroundProcess is NULL: %d\n", foregroundProcess == NULL); 
    // fprintf(stderr, "foregroundProcess->pid: %d\n", foregroundProcess->pid);
    // fprintf(stderr, "process->pid: %d\n", process->pid);
    // if current process == foreground -> make parent the foreground 
    if (foregroundProcess->pid == process->pid) {
      // if its a shell, can't set the parent to foreground bc null 
      if (process->pid == 1) {
        // If we are killing the shell, just exit the program
        exit(0);
      }

      // once process is stopped, can unblock parent 
      pcb* parent = getPcb(process->parentPID);
      if (parent->status == BLOCKED) {
        element* parentElem = makeElement(parent);

        // REMOVE PARENT FROM STOPPED
        popWithPid(getStoppedQ(), parent->pid);

        // PARENT = READY (STATUS & QUEUE)
        parent->status = READY;
        logUnblocked(getTicks(), parent->pid, parent->priorityLevel, parent->command);
        findAddBackElem(parentElem);
        // set parent as foreground 
        setForegroundProcess(parent);
      }
    }

    // ???
    // if shell = killed --> many orphans 
    // if child = killed & not waited on --> make parent a zombie?
    
    // terminate process
    k_process_cleanup(process);

	}
  //run scheduler i think bc somethings gotta change after signals
  schedule(); 
    
  return 0;
}

/*
Cleans up resources.
Called from p_waitpid and in k_process_kill
*/
int k_process_cleanup(pcb* process) {
  // TODO: update for foreground process
	// add to completedQ

  // fprintf(stderr, "in k_process_cleanup\n");
  // Pop the pcb and free
  pcb* popped = popWithPid(completedQ, process->pid);
  free (popped);
  // fprintf(stderr, "right before return in k_process_cleanup\n");
  return 0;
}
