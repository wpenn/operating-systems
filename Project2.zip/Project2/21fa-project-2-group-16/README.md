Read me for PennOS Group 16
Alex Shaw (alxshaw), Amy Shen (amyshen), Ellie Chen (echen), Wesley Penn (wespenn), and Nolan (nolanh9)


