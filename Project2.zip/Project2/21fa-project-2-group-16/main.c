#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <stdlib.h>
#include "userFuncs.h"
#include "shell.h"
#include "scheduler.h"
#include "queueOs.h"
#include "signal.h"
#include "userFuncs.h"
#include "shell_funcs.h"
#include "logFuncs.h"

/**
* Perform the main logic to run the penn-shredder shell program
*
* @param argc - the number of arguments passed in
* @param argv - the array of string arugments passed in
*/
int main(int argc, char *argv[]) {
	if (argc == 1) {
		// current pennOs without pennFAT
	} else if (argc == 2) {
		// have fatfs and use default log file
	} else if (argc == 3) {
		// have fatfs and the schedlog file
	} else {
		printf ("Invalid number of args to PennOS\n");
		exit(EXIT_FAILURE);
	}

	// Open logfile
	fp = fopen("logfile", "w");

	// Register the signal handlers
	registerSignalHandlers();

	// Sets up all of the queues
	setupQueues();
	setupShellQueue();

	// Sets up the contexts (schedulerFuncContext, idleProcessContext)
	setupContexts();

	// Spawn the shell process
	char *argsArray[] = { NULL };
	char* sName[] = {"shell", NULL}; 
	p_spawn(runShellLoop, argsArray, STDIN_FILENO, STDOUT_FILENO, sName, -1);

	char* idleProcessName[] = {"idle", NULL};
	idleProcessPcb = createPcb(0, -1, STDIN_FILENO, STDOUT_FILENO, 
			idleProcessContext, -2, idleProcessName);

	// Start the clock ticks
	clock_ticks();

	// Call schedule(), will first schedule the shell
	schedule();
	
	fclose(fp);
	exit(EXIT_SUCCESS);
}
