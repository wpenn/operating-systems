#include "pcb.h"

/**
Creates a new process and associated PCB
*/
pcb* k_process_create(pcb *parent, int priorityLevel, char** cmd, int fd0, int fd1);

/**
sends the signal to the specified process
*/
int k_process_kill(pcb *process, int signal);

/**
Cleans up a process when it is finished (freeing things, etc)
*/
int k_process_cleanup(pcb *process);