#include <string.h>
#include "queue.h"
/*
NOTE FOR PENNOS:
THIS FILE IS ONLY FOR USE IN THE SHELL TO HANDLE JOBS AND STOPPED VS BACKGROUND

NOT A SCHEDULER QUEUE FILE -- SHELL LEVEL ONLY
*/

int job_id_count;

/**
User action: ^Z
When user ^Z, push the job to stoppedQueue queue

Note: the job must already be running in fg
      must keep current fg job node in fork(?)
*/ 
void pushStoppedJob (shellQueue *q, node *job) {
  // fprintf(stderr, "pushing to stopped queue node with job_id: %d\n", job->job_id);
  if (stoppedIsEmpty(q)) {
    q->stoppedQueue = job;
  } else {
    node *currHead = q->stoppedQueue;
    while (currHead->next != NULL) {
      currHead = currHead->next;
    }
    currHead->next = job;    
  }
} 

/**
User action: penn-shell> <command> &
When user & in initial command

Note: the job must already be running in fg
      must keep current fg job node in fork(?)
*/ 
void pushNewJobToBg (shellQueue *q, node *job) {
  //fprintf(stderr, "pushing to background queue node with job_id: %d\n", job->job_id);
  if (backgroundIsEmpty(q)) {
    q->backgroundQueue = job;
  } else {
    node *currHead = q->backgroundQueue;

    int found = 0;

    if (job->job_id < currHead->job_id) {
      q->backgroundQueue = job;
      job->next = currHead;
      found = 1;
    }

    while (currHead->next != NULL && found == 0) {
      if (job->job_id > currHead->job_id && 
          job->job_id < currHead->next->job_id) {
        // add between curr and curr->next
        node* tmp = currHead->next;
        job->next = tmp;
        currHead->next = job;
        found = 1;
      } 
      currHead = currHead->next;
    }

    if (currHead->next == NULL && found == 0) {
      currHead->next = job;
      job->next = NULL;
    }
  }
}

/**
User action: penn-shell> bg
Moves most recent stoppped into running in the background

Throws: AN ERROR If there is no job in the background
*/
node* pushJobToBgFromStopped (shellQueue *q) {
  if (stoppedIsEmpty(q)) {
    fprintf(stderr, "Invalid command: No stopped jobs\n");
    return NULL;
  } else {
    node* job = popStoppedJob(q);
    pushNewJobToBg(q, job); 
    return job;
  }
}

/**
User action: penn-shell> bg 3
Moves job with specified id into running in the background

Throws: AN ERROR if the job id doesn't exist in the stopped
*/
node* pushJobToBgFromStoppedWithId (shellQueue *q, int job_id) {
  if (stoppedIsEmpty(q)) {
    fprintf(stderr, "Invalid command: No stopped jobs\n");
    return NULL;
    // TODO: Exit ?
  } else {
    node *job = popForStoppedWithId(q, job_id);
    if (job != NULL) {
      pushNewJobToBg(q, job);
      return job;
    } else {
      fprintf(stderr, "Invalid command: No stopped jobs\n");
      return NULL;
    }
  }
}

/**
User action: penn-shell> fg
Moves most recently stopped into foreground if there is any, 
else moves most recently added to background into foreground

Throws: AN ERROR If there is none in the stoppedQueue or backgroundQueue
*/
node* popForFg (shellQueue *q) {
  // If both queues are empty, throw an error
  if (stoppedIsEmpty(q) && backgroundIsEmpty(q)) {
    fprintf(stderr, "Invalid command: Nothing to bring to foreground\n");
    return NULL;
  }

  // Checks stoppedQueue first
  if (!stoppedIsEmpty(q)) {
    return popStoppedJob(q);
  } else {
    // TODO: Handle bringing job to foreground from background
    return popBgJob(q);
  }
  return NULL;
}

/**
User action: penn-shell> fg
Moves most recently stopped into foreground if there is any, 
else moves most recently added to background into foreground

Throws: AN ERROR If there is none in the stoppedQueue or backgroundQueue
*/
node* popForFgFromStopped (shellQueue *q) {
  // If both queues are empty, throw an error
  if (stoppedIsEmpty(q)) {
    return NULL;
  }

  return popStoppedJob(q);
}

/**
User action: penn-shell> fg
Moves most recently stopped into foreground if there is any, 
else moves most recently added to background into foreground

Throws: AN ERROR If there is none in the stoppedQueue or backgroundQueue
*/
node* popForFgFromBackground (shellQueue *q) {
  // If background queue empty, return null
  if (backgroundIsEmpty(q)) {
    return NULL;
  }

  return popBgJob(q);
}

/**
User action: penn-shell> fg 3
Moves job id with 3 into foreground (checks in stopped and background for this job id)

Throws: AN ERROR if job id 3 does not exist
*/
node* popForFgWithId (shellQueue *q, int job_id) {
  // If both queues are empty, throw an error
  if (stoppedIsEmpty(q) && backgroundIsEmpty(q)) {
    fprintf(stderr, "Invalid command: Nothing to bring to foreground\n");
    return NULL;
  }

  // Checks stoppedQueue first
  if (!stoppedIsEmpty(q)) {
    node* job = popForStoppedWithId(q, job_id);
    if (job != NULL) {
      return job;
      // TODO: Handle bringing job to foreground from background
    }
  }
  // If not in stopped, checks the backgroundQueue
  node* job = popForBgWithId(q, job_id);
  if (job != NULL) {
    return job;
    // TODO: Handle bringing job to foreground from background
  }
  return NULL;
}

/**
User action: penn-shell> fg 3
Moves job id with 3 into foreground (checks in stopped and background for this job id)

Throws: AN ERROR if job id 3 does not exist
*/
node* popForFgFromStoppedWithId (shellQueue *q, int job_id) {
  // If stopped queue is empty, return null
  if (stoppedIsEmpty(q)) {
    return NULL;
  }

  // Checks stoppedQueue
  node* job = popForStoppedWithId(q, job_id);
  if (job != NULL) {
    return job;
  }
  return NULL;
}

/**
User action: penn-shell> fg 3
Moves job id with 3 into foreground (checks in stopped and background for this job id)

Throws: AN ERROR if job id 3 does not exist
*/
node* popForFgFromBackgroundWithId (shellQueue *q, int job_id) {
  // If backround queues empty, return null
  if (backgroundIsEmpty(q)) {
    return NULL;
  }
  // If not in stopped, checks the backgroundQueue
  node* job = popForBgWithId(q, job_id);
  if (job != NULL) {
    return job;
  }
  return NULL;
}

/*
Removes the most recently added stopped job if there is one
*/
node* popStoppedJob (shellQueue *q) {
  node *tmpStopped = q->stoppedQueue;
  node *job;
  // If stoppedQueue is length 1
  if (tmpStopped->next == NULL) {
    job = tmpStopped;
    q->stoppedQueue = NULL;
    return job;   
  } else {
    // If stoppedQueue's length is > 1
    while (tmpStopped->next->next != NULL) {
      tmpStopped = tmpStopped->next;
    }
    job = tmpStopped->next;
    tmpStopped->next = NULL;
    return job;
  }
}


/*
Removes the most recently added background job if there is one
*/
node* popBgJob (shellQueue *q) {
  // Take most recent from backgroundQueue
  node *tmpBackground = q->backgroundQueue;
  node *job;
  // If backgroundQueue is length 1
  if (tmpBackground->next == NULL) {
    job = tmpBackground;
    q->backgroundQueue = NULL;
    return job;   
  } else {
    // If backgroundQueue's length is > 1
    while (tmpBackground->next->next != NULL) {
      tmpBackground = tmpBackground->next;
    }
    job = tmpBackground->next;
    tmpBackground->next = NULL;
    return job;
  }
}

/*
Removes the stopped job from the queue with specified id

Returns NULL if the background queue doesn't contain the specified id
*/
node* popForStoppedWithId (shellQueue *q, int job_id) {
  // Remove from stoppedQueue and add to backgroundQueue
  node *currHead = q->stoppedQueue;
  node* job;

  // If stoppedQueue is length 1
  if (currHead->next == NULL) {
    if (currHead->job_id == job_id) {
      job = currHead;
      q->stoppedQueue = NULL;
      return job;
    } else {
      fprintf(stderr, "Invalid: No stopped job with id %d\n", job_id);
      return NULL;
      // TODO: Exit ?
    }
  } else {
    // If stoppedQueue's length is > 1
    node *currHead = q->stoppedQueue;

    // If job id is at head
    if (currHead->job_id == job_id) {
      q->stoppedQueue = currHead->next;
      job = currHead;
      job->next = NULL;
      //pushNewJobToBg(q, job);
      return job;
    }

    // If job id is not at head
    while (currHead->next != NULL) {
      if (currHead->next->job_id == job_id) {
        job = currHead->next;
        currHead->next = currHead->next->next;
        job->next = NULL;
        //pushNewJobToBg(q, job);
        return job;
      }
      currHead = currHead->next;
    }
    fprintf(stderr, "Invalid: No stopped job with id %d\n", job_id);
    return NULL;
  }
}

/*
Removes the background job from the queue with specified id

Returns NULL if the background queue doesn't contain the specified id
*/
node* popForBgWithId (shellQueue *q, int job_id) {
  node *currHead = q->backgroundQueue;
  node* job;

  if (currHead == NULL) {
    // maybe print something idk
    fprintf (stderr, "Invalid:  No background job with id %d\n", job_id);
    return NULL;
  }
  // If backgroundQueue is length 1
  if (currHead->next == NULL) {
    if (currHead->job_id == job_id) {
      // job = currHead;
      q->backgroundQueue = NULL;
      return currHead;
    } else {
      fprintf(stderr, "Invalid: No background job with id %d\n", job_id);
      return NULL;
      // TODO: Exit ?
    }
  } else {
    // If backgroundQueue's length is > 1
    // If job id is at head
    if (currHead->job_id == job_id) {
      q->backgroundQueue = currHead->next;
      job = currHead;
      job->next = NULL;
      //pushNewJobToBg(q, job);
      return job;
    }

    // If job id is not at head
    while (currHead->next != NULL) {
      if (currHead->next->job_id == job_id) {
        job = currHead->next;
        currHead->next = currHead->next->next;
        job->next = NULL;
        //pushNewJobToBg(q, job);
        return job;
      }
      currHead = currHead->next;
    }
    fprintf(stderr, "Invalid: No background job with id %d\n", job_id);
    return NULL;
  }
}

/*
Checks if background queue is empty
*/
int backgroundIsEmpty (shellQueue *q) {
  return (q->backgroundQueue == NULL);
}

/*
Checks if stopped queue is empty
*/
int stoppedIsEmpty(shellQueue *q) {
  return (q->stoppedQueue == NULL);
}


/*
Creates a node
*/
node* makeNode(int job_id, pcb* pcb) {
  node *n = malloc (sizeof(node));
  n->job_id = job_id;
  n->next = NULL;
  n->pcb = pcb;
  return n;
}

/*
Find node in background with given pid

Returns a pointer to the node in the queue
Returns null if no node exists with that pid
*/
node* findNode(shellQueue* q, int pid) {
  node *currNode = q->backgroundQueue;
  while (currNode != NULL) {
    if (currNode->pcb->pid == pid) {
      return currNode;
    }
    currNode = currNode->next;
  }
  return NULL;
}

/*
Prints all of the pipes of the current command together in the jobs format
Helper method for print jobs
*/
void printCurrCommand (node* n) {
  fprintf (stderr, "[%d] ", n->job_id);

  int currWordIdx = 0;
  while (n->pcb->command[currWordIdx] != NULL) {
      fprintf (stderr, "%s ", n->pcb->command[currWordIdx]);
      currWordIdx++; 
  }
}

/*
User action: penn-shell> jobs
Prints the jobs in order of their job_id
*/
void printJobs(shellQueue *q) {
  /* TODO : need to print input and output redirection 
            if there is at the first and last comand
  */          
  node *tmpBg = q->backgroundQueue;
  node *tmpStopped = q->stoppedQueue;

  while (tmpBg != NULL && tmpStopped != NULL) {
    if (tmpBg->job_id < tmpStopped->job_id) {
      printCurrCommand(tmpBg);
      fprintf (stderr, "(running)\n");
      tmpBg = tmpBg->next;
    } else {
      printCurrCommand(tmpStopped);
      fprintf(stderr, "(stopped)\n");
      tmpStopped = tmpStopped->next;
    }
  }
  
  while (tmpBg != NULL) {
    printCurrCommand(tmpBg);
    fprintf (stderr, "(running)\n");
    tmpBg = tmpBg->next;
  }

  while (tmpStopped != NULL) {
    printCurrCommand(tmpStopped);
    fprintf(stderr, "(stopped)\n");
    tmpStopped = tmpStopped->next;
  }
}

/*
Debugging method that prints the current background queue
*/
void printBackgroundQueue(shellQueue *q) {
  fprintf (stderr, "Printing Background Queue\n");
  node *tmp = q->backgroundQueue;
  while (tmp != NULL) {
    fprintf (stderr, "background node job_id: %d\n", tmp->job_id);
    tmp = tmp->next;
  }
  fprintf (stderr, "\n");
}

/*
Debugging method that prints the current stopped queue
*/
void printStoppedQueue(shellQueue *q) {
  fprintf (stderr, "Printing Stopped Queue\n");
  node *tmp = q->stoppedQueue;
  while (tmp != NULL) {
    fprintf (stderr, "stopped node job_id: %d\n", tmp->job_id);
    tmp = tmp->next;
  }
  fprintf (stderr, "\n");
}

/*
Free all nodes and free the queue
*/
void freeQueue(shellQueue *q) {
  node* bgHead = q->backgroundQueue;
  while(bgHead != NULL) {
    node* tempBgHead = bgHead;
    bgHead = tempBgHead->next;
    freeNode(tempBgHead);
  }

  node* stoppedHead = q->stoppedQueue;
  while(stoppedHead != NULL) {
    node* tempStoppedHead = stoppedHead;
    stoppedHead = tempStoppedHead->next;
    freeNode(tempStoppedHead);
  }
  free(q);
}

/*
Just free the node for now
*/
void freeNode(node* n) {
  free(n);
}



