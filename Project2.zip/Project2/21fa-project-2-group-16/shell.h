#include <stdlib.h>
#include "queue.h"

#define MAX_LINE_LENGTH 4096

shellQueue* q;
int job_id;

void runShellLoop();
void executeCommand(char * cmd, int * overWriteFDIN, int * overWriteFDOUT);