#include <stdio.h>
#include "logFuncs.h"

FILE* getFile() {
	return fp;
}

void logCreate(int ticks, int pid, int priorityLevel, char** cmd) {
    fprintf(getFile(), "[%d]\t CREATE   \t%d\t%d\t%s\n", ticks, pid, priorityLevel, cmd[0]);
    fflush(getFile());
}

void logSignaled(int ticks, int pid, int priorityLevel, char** cmd) {
    fprintf(getFile(), "[%d]\t SIGNALED \t%d\t%d\t%s\n", ticks, pid, priorityLevel, cmd[0]);
    fflush(getFile());
}

void logStopped(int ticks, int pid, int priorityLevel, char** cmd) {
    fprintf(getFile(), "[%d]\t STOPPED  \t%d\t%d\t%s\n", ticks, pid, priorityLevel, cmd[0]);
    fflush(getFile());
}

void logContinued(int ticks, int pid, int priorityLevel, char** cmd) {
    fprintf(getFile(), "[%d]\t CONTINUED\t%d\t%d\t%s\n", ticks, pid, priorityLevel, cmd[0]);
    fflush(getFile());
}

void logSchedule(int ticks, int pid, int priorityLevel, char** cmd) {
    fprintf(getFile(), "[%d]\t SCHEDULE \t%d\t%d\t%s\n", ticks, pid, priorityLevel, cmd[0]);
    fflush(getFile());
}

// Are there two logNices ?
// void logNice(int ticks, int pid, int old, int new, char* cmd) {
//     fprintf(getFile(), "[%d]\t NICE\t%d\t%d\t%d\t%s\n", ticks, pid, old, new, cmd);
//     fflush(getFile());
// }

void logUnblocked(int ticks, int pid, int priorityLevel, char** cmd) {
    fprintf(getFile(), "[%d]\t UNBLOCKED\t%d\t%d\t%s\n", ticks, pid, priorityLevel, cmd[0]);
}

void logBlocked(int ticks, int pid, int priorityLevel, char** cmd) {
    fprintf(getFile(), "[%d]\t BLOCKED\t%d\t%d\t%s\n", ticks, pid, priorityLevel, cmd[0]);
}

void logNice(int ticks, int pid, char** cmd) {
    fprintf(getFile(), "[%d]\t NICE     \t%d\t-1\t0\t%s\n", ticks, pid, cmd[0]);
    fflush(getFile());
}

void logReaped(int ticks, int pid, char** cmd) {
    fprintf(getFile(), "[%d]\t REAPED\t%d\t-1\t0\t%s\n", ticks, pid, cmd[0]);
    fflush(getFile());
}